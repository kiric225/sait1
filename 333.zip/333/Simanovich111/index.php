<?php
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'Simanovich1';

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die ("ошибка подключения: " . mysqli_connect_error());
}
echo "успешное подключение к базе данных! ";

$password = "my_secure_password";
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);
echo $hashedPassword
?>