<?php
$errors = [];
$success = false;

// Получение информации о пользователе
$user_id = $_SESSION['user_id'];
$stmt = $db->prepare("SELECT full_name, phone, email FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Получение списка ресторанов
$restaurants = $db->query("SELECT id, name FROM restaurants");

// Получение истории заказов пользователя
$orders = $db->query("
    SELECT o.id, o.created_at, r.name as restaurant_name, o.status, SUM(oi.price * oi.quantity) as total
    FROM orders o
    JOIN restaurants r ON o.restaurant_id = r.id
    JOIN order_items oi ON o.id = oi.order_id
    WHERE o.user_id = $user_id
    GROUP BY o.id
    ORDER BY o.created_at DESC
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $restaurant_id = intval($_POST['restaurant_id']);
    $delivery_address = trim($_POST['delivery_address']);
    $phone = trim($_POST['phone']);
    $delivery_time = trim($_POST['delivery_time']);
    $dishes = $_POST['dishes'] ?? [];

    // Валидация
    if (empty($restaurant_id)) $errors[] = "Выберите ресторан";
    if (empty($delivery_address)) $errors[] = "Укажите адрес доставки";
    if (empty($phone)) {
        $errors[] = "Телефон обязателен для заполнения";
    } elseif (!preg_match('/^\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $errors[] = "Телефон должен быть в формате (XXX)-XXX-XX-XX";
    }
    if (empty($delivery_time)) $errors[] = "Укажите дату и время доставки";
    
    $has_dishes = false;
    foreach ($dishes as $dish_id => $quantity) {
        if ($quantity > 0) {
            $has_dishes = true;
            break;
        }
    }
    if (!$has_dishes) $errors[] = "Добавьте хотя бы одно блюдо в заказ";

    if (empty($errors)) {
        // Создание заказа
        $db->begin_transaction();
        
        try {
            $stmt = $db->prepare("INSERT INTO orders (user_id, restaurant_id, delivery_address, phone, delivery_time) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("iisss", $user_id, $restaurant_id, $delivery_address, $phone, $delivery_time);
            $stmt->execute();
            $order_id = $db->insert_id;
            
            foreach ($dishes as $dish_id => $quantity) {
                if ($quantity > 0) {
                    // Получаем цену блюда
                    $dish_stmt = $db->prepare("SELECT price FROM dishes WHERE id = ?");
                    $dish_stmt->bind_param("i", $dish_id);
                    $dish_stmt->execute();
                    $dish_result = $dish_stmt->get_result();
                    $dish = $dish_result->fetch_assoc();
                    
                    $stmt = $db->prepare("INSERT INTO order_items (order_id, dish_id, quantity, price) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("iiid", $order_id, $dish_id, $quantity, $dish['price']);
                    $stmt->execute();
                }
            }
            
            $db->commit();
            $success = true;
        } catch (Exception $e) {
            $db->rollback();
            $errors[] = "Ошибка при создании заказа: " . $e->getMessage();
        }
    }
}

// Получение блюд для выбранного ресторана (если есть)
$selected_restaurant_id = $_POST['restaurant_id'] ?? ($restaurants->num_rows > 0 ? $restaurants->fetch_assoc()['id'] : 0);
$dishes_list = [];
if ($selected_restaurant_id) {
    $dishes_list = $db->query("SELECT id, name, price FROM dishes WHERE restaurant_id = $selected_restaurant_id");
}
?>

<h2>Создание заказа</h2>

<?php if ($success): ?>
    <div style="color: green;">Заказ успешно создан!</div>
    <p><a href="?page=order">Создать новый заказ</a></p>
<?php else: ?>
    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <h3>История ваших заказов</h3>
    <?php if ($orders->num_rows > 0): ?>
        <table border="1">
            <tr>
                <th>№</th>
                <th>Дата</th>
                <th>Ресторан</th>
                <th>Статус</th>
                <th>Сумма</th>
            </tr>
            <?php while ($order = $orders->fetch_assoc()): ?>
                <tr>
                    <td><?= $order['id'] ?></td>
                    <td><?= $order['created_at'] ?></td>
                    <td><?= $order['restaurant_name'] ?></td>
                    <td><?= $order['status'] ?></td>
                    <td><?= $order['total'] ?> руб.</td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>У вас еще нет заказов</p>
    <?php endif; ?>

    <h3>Новый заказ</h3>
    <form method="post">
        <div>
            <label>Ресторан:</label>
            <select name="restaurant_id" required>
                <option value="">Выберите ресторан</option>
                <?php while ($restaurant = $restaurants->fetch_assoc()): ?>
                    <option value="<?= $restaurant['id'] ?>" <?= ($restaurant['id'] == $selected_restaurant_id) ? 'selected' : '' ?>>
                        <?= $restaurant['name'] ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        
        <div>
            <label>Адрес доставки:</label>
            <input type="text" name="delivery_address" value="<?= htmlspecialchars($_POST['delivery_address'] ?? '') ?>" required>
        </div>
        
        <div>
            <label>Телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? $user['phone']) ?>" required>
        </div>
        
        <div>
            <label>Дата и время доставки:</label>
            <input type="datetime-local" name="delivery_time" value="<?= htmlspecialchars($_POST['delivery_time'] ?? '') ?>" required>
        </div>
        
        <h4>Меню ресторана</h4>
        <?php if ($dishes_list->num_rows > 0): ?>
            <table border="1">
                <tr>
                    <th>Блюдо</th>
                    <th>Цена</th>
                    <th>Количество</th>
                </tr>
                <?php while ($dish = $dishes_list->fetch_assoc()): ?>
                    <tr>
                        <td><?= $dish['name'] ?></td>
                        <td><?= $dish['price'] ?> руб.</td>
                        <td>
                            <input type="number" name="dishes[<?= $dish['id'] ?>]" value="<?= $_POST['dishes'][$dish['id']] ?? 0 ?>" min="0">
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p>Выберите ресторан для просмотра меню</p>
        <?php endif; ?>
        
        <button type="submit">Оформить заказ</button>
    </form>
<?php endif; ?>