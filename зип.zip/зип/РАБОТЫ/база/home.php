<h2>Добро пожаловать в "Быстро и Вкусно"!</h2>

<?php if ($is_logged_in): ?>
    <p>Вы авторизованы как <?= $is_admin ? 'администратор' : 'пользователь' ?>.</p>
    <p>
        <?php if ($is_admin): ?>
            <a href="?page=admin">Перейти в панель администратора</a>
        <?php else: ?>
            <a href="?page=order">Перейти к заказу</a>
        <?php endif; ?>
    </p>
    <p><a href="?page=logout">Выйти</a></p>
<?php else: ?>
    <p>Пожалуйста, <a href="?page=login">войдите</a> или <a href="?page=register">зарегистрируйтесь</a> для оформления заказов.</p>
<?php endif; ?>