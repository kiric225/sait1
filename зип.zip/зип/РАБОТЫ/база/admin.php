<?php
// Изменение статуса заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    
    $stmt = $db->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
}

// Получение всех заказов
$orders = $db->query("
    SELECT o.id, o.created_at, u.full_name, u.phone, r.name as restaurant_name, o.status, 
           o.delivery_address, o.delivery_time, SUM(oi.price * oi.quantity) as total
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN restaurants r ON o.restaurant_id = r.id
    JOIN order_items oi ON o.id = oi.order_id
    GROUP BY o.id
    ORDER BY o.created_at DESC
");
?>

<h2>Панель администратора</h2>

<table border="1">
    <tr>
        <th>№</th>
        <th>Дата</th>
        <th>Клиент</th>
        <th>Телефон</th>
        <th>Ресторан</th>
        <th>Адрес доставки</th>
        <th>Время доставки</th>
        <th>Статус</th>
        <th>Сумма</th>
        <th>Действия</th>
    </tr>
    <?php while ($order = $orders->fetch_assoc()): ?>
        <tr>
            <td><?= $order['id'] ?></td>
            <td><?= $order['created_at'] ?></td>
            <td><?= $order['full_name'] ?></td>
            <td><?= $order['phone'] ?></td>
            <td><?= $order['restaurant_name'] ?></td>
            <td><?= $order['delivery_address'] ?></td>
            <td><?= $order['delivery_time'] ?></td>
            <td><?= $order['status'] ?></td>
            <td><?= $order['total'] ?> руб.</td>
            <td>
                <form method="post" style="display: inline;">
                    <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                    <select name="status" onchange="this.form.submit()">
                        <option value="new" <?= $order['status'] == 'new' ? 'selected' : '' ?>>Новый</option>
                        <option value="preparing" <?= $order['status'] == 'preparing' ? 'selected' : '' ?>>В процессе приготовления</option>
                        <option value="delivering" <?= $order['status'] == 'delivering' ? 'selected' : '' ?>>Доставка осуществляется</option>
                        <option value="completed" <?= $order['status'] == 'completed' ? 'selected' : '' ?>>Заказ выполнен</option>
                        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                    </select>
                </form>
            </td>
        </tr>
        
        <!-- Детали заказа -->
        <tr>
            <td colspan="10">
                <strong>Состав заказа:</strong><br>
                <?php
                $items = $db->query("
                    SELECT d.name, oi.quantity, oi.price
                    FROM order_items oi
                    JOIN dishes d ON oi.dish_id = d.id
                    WHERE oi.order_id = {$order['id']}
                ");
                
                while ($item = $items->fetch_assoc()) {
                    echo "{$item['name']} - {$item['quantity']} x {$item['price']} руб.<br>";
                }
                ?>
            </td>
        </tr>
    <?php endwhile; ?>
</table>