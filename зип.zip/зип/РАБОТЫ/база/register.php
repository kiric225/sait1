<?php
$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);

    // Валидация
    if (empty($full_name)) $errors[] = "ФИО обязательно для заполнения";
    if (empty($phone)) {
        $errors[] = "Телефон обязателен для заполнения";
    } elseif (!preg_match('/^\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $errors[] = "Телефон должен быть в формате (XXX)-XXX-XX-XX";
    }
    if (empty($email)) {
        $errors[] = "Email обязателен для заполнения";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Некорректный формат email";
    }
    if (empty($login)) $errors[] = "Логин обязателен для заполнения";
    if (empty($password)) {
        $errors[] = "Пароль обязателен для заполнения";
    } elseif (strlen($password) < 6) {
        $errors[] = "Пароль должен содержать минимум 6 символов";
    }
    if ($password !== $confirm_password) $errors[] = "Пароли не совпадают";

    if (empty($errors)) {
        // Проверка, что email не занят
        $stmt = $db->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();
        
        if ($stmt->num_rows > 0) {
            $errors[] = "Пользователь с таким email уже зарегистрирован";
        } else {
            // Регистрация пользователя
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            $stmt = $db->prepare("INSERT INTO users (full_name, phone, email, login, password) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $full_name, $phone, $email, $login, $hashed_password);
            
            if ($stmt->execute()) {
                $success = true;
            } else {
                $errors[] = "Ошибка при регистрации: " . $db->error;
            }
        }
    }
}
?>

<h2>Регистрация</h2>

<?php if ($success): ?>
    <div style="color: green;">Регистрация успешно завершена! <a href="?page=login">Войдите</a> в систему.</div>
<?php else: ?>
    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post">
        <div>
            <label>ФИО:</label>
            <input type="text" name="full_name" value="<?= htmlspecialchars($_POST['full_name'] ?? '') ?>" required>
        </div>
        <div>
            <label>Телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
        </div>
        <div>
            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
        </div>
        <div>
            <label>Логин:</label>
            <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required>
        </div>
        <div>
            <label>Пароль (минимум 6 символов):</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Подтвердите пароль:</label>
            <input type="password" name="confirm_password" required>
        </div>
        <button type="submit">Зарегистрироваться</button>
    </form>
    <p>Уже зарегистрированы? <a href="?page=login">Войдите</a>.</p>
<?php endif; ?>