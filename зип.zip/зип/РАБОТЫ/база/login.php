<?php
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);

    if (empty($login) || empty($password)) {
        $errors[] = "Логин и пароль обязательны для заполнения";
    } else {
        // Проверка администратора
        if ($login === 'admin') {
            $stmt = $db->prepare("SELECT id, password FROM users WHERE login = 'admin' LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['is_admin'] = true;
                header("Location: ?page=admin");
                exit;
            }
        }

        // Проверка обычного пользователя
        $stmt = $db->prepare("SELECT id, password FROM users WHERE login = ? LIMIT 1");
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = false;
            header("Location: ?page=order");
            exit;
        } else {
            $errors[] = "Неверный логин или пароль";
        }
    }
}
?>

<h2>Авторизация</h2>

<?php if (!empty($errors)): ?>
    <div style="color: red;">
        <?php foreach ($errors as $error): ?>
            <p><?= $error ?></p>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<form method="post">
    <div>
        <label>Логин:</label>
        <input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required>
    </div>
    <div>
        <label>Пароль:</label>
        <input type="password" name="password" required>
    </div>
    <button type="submit">Войти</button>
</form>
<p>Еще не зарегистрированы? <a href="?page=register">Зарегистрируйтесь</a>.</p>