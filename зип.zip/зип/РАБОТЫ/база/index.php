<?php
session_start();

// Подключение к базе данных
$db = new mysqli('localhost', 'root', 'root', 'food_delivery225'); // Изменено здесь

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
// Проверка авторизации
$is_logged_in = isset($_SESSION['user_id']);
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Маршрутизация
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

switch ($page) {
    case 'register':
        include 'register.php';
        break;
    case 'login':
        include 'login.php';
        break;
    case 'logout':
        include 'logout.php';
        break;
    case 'order':
        if ($is_logged_in) {
            include 'order.php';
        } else {
            header("Location: ?page=login");
        }
        break;
    case 'admin':
        if ($is_admin) {
            include 'admin.php';
        } else {
            header("Location: ?page=login");
        }
        break;
    default:
        include 'home.php';
        break;
}
?>