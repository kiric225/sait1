<?php
session_start();
require_once 'config.php';

if (!isLoggedIn() || !isAdmin()) {
    header('Location: login.php');
    exit;
}

// Получение всех заказов
$orders = $pdo->query("
    SELECT o.*, u.full_name, u.phone as user_phone, u.email 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
")->fetchAll();

// Обновление статуса заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);
    header('Location: admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Панель администратора</title>
</head>
<body>
    <h1>Панель администратора</h1>
    <p>Вы вошли как администратор. <a href="logout.php">Выйти</a></p>
    
    <h2>Все заказы</h2>
    <?php if (empty($orders)): ?>
        <p>Нет заказов</p>
    <?php else: ?>
        <table border="1">
            <tr>
                <th>№</th>
                <th>Клиент</th>
                <th>Контакты</th>
                <th>Адрес</th>
                <th>Дата уборки</th>
                <th>Статус</th>
                <th>Услуги</th>
                <th>Действия</th>
            </tr>
            <?php foreach ($orders as $order): ?>
                <tr>
                    <td><?= $order['id'] ?></td>
                    <td><?= htmlspecialchars($order['full_name']) ?></td>
                    <td>
                        <?= htmlspecialchars($order['user_phone']) ?><br>
                        <?= htmlspecialchars($order['email']) ?>
                    </td>
                    <td><?= htmlspecialchars($order['address']) ?></td>
                    <td><?= date('d.m.Y H:i', strtotime($order['order_date'])) ?></td>
                    <td>
                        <?php 
                        $statuses = [
                            'new' => 'Новый',
                            'processing' => 'В обработке',
                            'in_progress' => 'В процессе',
                            'completed' => 'Завершен',
                            'cancelled' => 'Отменен'
                        ];
                        echo $statuses[$order['status']] ?? $order['status'];
                        ?>
                    </td>
                    <td>
                        <?php
                        $stmt = $pdo->prepare("SELECT s.name FROM order_items oi JOIN services s ON oi.service_id = s.id WHERE oi.order_id = ?");
                        $stmt->execute([$order['id']]);
                        $items = $stmt->fetchAll();
                        echo implode(', ', array_column($items, 'name'));
                        ?>
                    </td>
                    <td>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                            <select name="status">
                                <option value="new" <?= $order['status'] === 'new' ? 'selected' : '' ?>>Новый</option>
                                <option value="processing" <?= $order['status'] === 'processing' ? 'selected' : '' ?>>В обработке</option>
                                <option value="in_progress" <?= $order['status'] === 'in_progress' ? 'selected' : '' ?>>В процессе</option>
                                <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Завершен</option>
                                <option value="cancelled" <?= $order['status'] === 'cancelled' ? 'selected' : '' ?>>Отменен</option>
                            </select>
                            <button type="submit" name="update_status">Обновить</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</body>
</html>