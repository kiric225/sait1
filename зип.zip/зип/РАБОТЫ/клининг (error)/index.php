<?php
session_start();
require_once 'config.php';

// Перенаправление на соответствующую страницу
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['is_admin']) {
        header('Location: admin.php');
    } else {
        header('Location: orders.php');
    }
} else {
    header('Location: login.php');
}
?>
