<?php
// Настройки подключения к базе данных
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'root');
define('DB_NAME', 'cleaning_company');
define('BASE_URL', 'http://localhost/cleaning_company/');

// Настройки системы
define('ADMIN_LOGIN', 'admin');
define('ADMIN_PASSWORD', 'delivery123');
define('MIN_PASSWORD_LENGTH', 6);

// Подключение к базе данных с обработкой ошибок
function getDBConnection() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", 
                DB_USER, 
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false
                ]
            );
        } catch (PDOException $e) {
            error_log("DB Error: " . $e->getMessage());
            die("Ошибка подключения к базе данных. Пожалуйста, попробуйте позже.");
        }
    }
    
    return $pdo;
}

// Функции для работы с сессией
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function isAdmin() {
    return isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
}

function redirect($url) {
    header("Location: " . BASE_URL . $url);
    exit;
}

// Защита от XSS
function sanitize($data) {
    if (is_array($data)) {
        return array_map('sanitize', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Валидация телефона
function validatePhone($phone) {
    return preg_match('/^\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone);
}

// Инициализация сессии
session_start();
?>