<?php
require_once 'config.php';

// Если пользователь уже авторизован, перенаправляем его
if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin.php' : 'orders.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = sanitize($_POST['login'] ?? '');
    $password = sanitize($_POST['password'] ?? '');
    
    try {
        $pdo = getDBConnection();
        
        // Проверка администратора
        if ($login === ADMIN_LOGIN && $password === ADMIN_PASSWORD) {
            $_SESSION['user_id'] = 0;
            $_SESSION['is_admin'] = true;
            $_SESSION['full_name'] = 'Администратор';
            redirect('admin.php');
        }
        
        // Проверка обычного пользователя
        $stmt = $pdo->prepare("SELECT id, full_name, password FROM users WHERE login = ?");
        $stmt->execute([$login]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['is_admin'] = false;
            $_SESSION['full_name'] = $user['full_name'];
            redirect('orders.php');
        } else {
            $error = 'Неверный логин или пароль';
        }
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        $error = 'Ошибка при входе в систему. Пожалуйста, попробуйте позже.';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в систему - Клининговая компания</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 15px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input { width: 100%; padding: 8px; box-sizing: border-box; }
        button { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background: #0056b3; }
    </style>
</head>
<body>
    <h1>Вход в систему</h1>
    
    <?php if ($error): ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>
    
    <form method="POST" novalidate>
        <div class="form-group">
            <label for="login">Логин:</label>
            <input type="text" id="login" name="login" required>
        </div>
        
        <div class="form-group">
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <button type="submit">Войти</button>
    </form>
    
    <p style="margin-top: 20px;">
        Ещё не зарегистрированы? <a href="register.php">Создать аккаунт</a>
    </p>
</body>
</html>