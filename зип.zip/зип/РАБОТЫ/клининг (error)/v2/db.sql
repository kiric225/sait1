-- Удаляем базу данных, если она существует (для тестирования)
DROP DATABASE IF EXISTS cleaning_company;
CREATE DATABASE cleaning_company CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cleaning_company;

-- Таблица пользователей с улучшенной структурой
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY (email),
    UNIQUE KEY (login)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица услуг с категориями
CREATE TABLE services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category ENUM('regular', 'deep', 'special') NOT NULL DEFAULT 'regular',
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    duration INT COMMENT 'Продолжительность в минутах',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица заказов с улучшенными статусами
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address TEXT NOT NULL,
    phone VARCHAR(20) NOT NULL,
    order_date DATETIME NOT NULL,
    total_price DECIMAL(10, 2),
    status ENUM('new', 'confirmed', 'in_progress', 'completed', 'cancelled') DEFAULT 'new',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица элементов заказа с количеством и ценой на момент заказа
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    service_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    item_price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Добавляем администратора
INSERT INTO users (full_name, phone, email, login, password) 
VALUES (
    'Администратор Системы', 
    '(123)-456-78-90', 
    'admin@cleaning.ru', 
    'admin', 
    '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi' -- password: delivery123
);

-- Добавляем услуги клининга
INSERT INTO services (category, name, description, price, duration) VALUES 
('regular', 'Генеральная уборка', 'Полная уборка всей квартиры или дома', 5000.00, 240),
('regular', 'Поддерживающая уборка', 'Еженедельная стандартная уборка', 3500.00, 180),
('deep', 'Мытье окон', 'Чистка всех окон в помещении', 2000.00, 120),
('deep', 'Химчистка ковров', 'Профессиональная чистка ковровых покрытий', 3000.00, 180),
('special', 'Уборка после ремонта', 'Уборка строительного мусора и пыли после ремонта', 8000.00, 300),
('special', 'Уборка офиса', 'Комплексная уборка офисных помещений', 6000.00, 240);