<?php
require_once 'config.php';

// Проверка авторизации
if (!isLoggedIn() || isAdmin()) {
    redirect('login.php');
}

$errors = [];
$success = '';

try {
    $pdo = getDBConnection();
    
    // Получение истории заказов пользователя
    $stmt = $pdo->prepare("
        SELECT o.* 
        FROM orders o 
        WHERE o.user_id = ? 
        ORDER BY o.order_date DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll();
    
    // Получение списка активных услуг
    $services = $pdo->query("
        SELECT * 
        FROM services 
        WHERE is_active = TRUE
        ORDER BY category, name
    ")->fetchAll();
    
    // Создание нового заказа
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_order'])) {
        $address = sanitize($_POST['address'] ?? '');
        $phone = sanitize($_POST['phone'] ?? '');
        $order_date = sanitize($_POST['order_date'] ?? '');
        $services_ids = $_POST['services'] ?? [];
        $notes = sanitize($_POST['notes'] ?? '');
        
        // Валидация
        if (empty($address)) {
            $errors[] = 'Укажите адрес уборки';
        }
        
        if (empty($phone) || !validatePhone($phone)) {
            $errors[] = 'Телефон должен быть в формате (XXX)-XXX-XX-XX';
        }
        
        if (empty($order_date)) {
            $errors[] = 'Укажите дату и время уборки';
        } elseif (strtotime($order_date) < strtotime('today')) {
            $errors[] = 'Дата уборки не может быть в прошлом';
        }
        
        if (empty($services_ids)) {
            $errors[] = 'Выберите хотя бы одну услугу';
        }
        
        if (empty($errors)) {
            $pdo->beginTransaction();
            
            try {
                // Создаем заказ
                $stmt = $pdo->prepare("
                    INSERT INTO orders (user_id, address, phone, order_date, notes) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([
                    $_SESSION['user_id'],
                    $address,
                    $phone,
                    $order_date,
                    $notes
                ]);
                $order_id = $pdo->lastInsertId();
                
                // Добавляем услуги в заказ и рассчитываем общую стоимость
                $total_price = 0;
                $stmt_service = $pdo->prepare("SELECT price FROM services WHERE id = ?");
                $stmt_insert = $pdo->prepare("
                    INSERT INTO order_items (order_id, service_id, quantity, item_price) 
                    VALUES (?, ?, 1, ?)
                ");
                
                foreach ($services_ids as $service_id) {
                    $stmt_service->execute([$service_id]);
                    $service = $stmt_service->fetch();
                    
                    if ($service) {
                        $stmt_insert->execute([$order_id, $service_id, $service['price']]);
                        $total_price += $service['price'];
                    }
                }
                
                // Обновляем общую стоимость заказа
                $stmt = $pdo->prepare("UPDATE orders SET total_price = ? WHERE id = ?");
                $stmt->execute([$total_price, $order_id]);
                
                $pdo->commit();
                $success = 'Заказ успешно создан!';
                
                // Обновляем список заказов
                $stmt = $pdo->prepare("
                    SELECT o.* 
                    FROM orders o 
                    WHERE o.user_id = ? 
                    ORDER BY o.order_date DESC
                ");
                $stmt->execute([$_SESSION['user_id']]);
                $orders = $stmt->fetchAll();
            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("Order creation error: " . $e->getMessage());
                $errors[] = 'Ошибка при создании заказа. Пожалуйста, попробуйте позже.';
            }
        }
    }
} catch (PDOException $e) {
    error_log("Orders page error: " . $e->getMessage());
    $errors[] = 'Ошибка при загрузке данных. Пожалуйста, попробуйте позже.';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заказы - Клининговая компания</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 15px; }
        .error ul, .success ul { margin: 0; padding-left: 20px; }
        .success { color: green; margin-bottom: 15px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea, select { width: 100%; padding: 8px; box-sizing: border-box; margin-bottom: 10px; }
        button { padding: 10px 15px; background: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background: #0056b3; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .service-category { margin-top: 20px; font-weight: bold; color: #333; }
        .service-item { margin-left: 20px; }
        .status-new { color: #007bff; }
        .status-confirmed { color: #17a2b8; }
        .status-in_progress { color: #ffc107; }
        .status-completed { color: #28a745; }
        .status-cancelled { color: #dc3545; }
    </style>
</head>
<body>
    <h1>Мои заказы</h1>
    <p>Добро пожаловать, <?= sanitize($_SESSION['full_name']) ?>! <a href="logout.php">Выйти</a></p>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>
    
    <h2>Новый заказ</h2>
    <form method="POST" novalidate>
        <div class="form-group">
            <label for="address">Адрес уборки:</label>
            <input type="text" id="address" name="address" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Контактный телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" id="phone" name="phone" placeholder="(XXX)-XXX-XX-XX" required>
        </div>
        
        <div class="form-group">
            <label for="order_date">Дата и время уборки:</label>
            <input type="datetime-local" id="order_date" name="order_date" required>
        </div>
        
        <div class="form-group">
            <label for="notes">Дополнительные пожелания:</label>
            <textarea id="notes" name="notes" rows="3"></textarea>
        </div>
        
        <div class="form-group">
            <label>Выберите услуги:</label>
            
            <?php
            $current_category = null;
            foreach ($services as $service):
                if ($service['category'] !== $current_category):
                    $current_category = $service['category'];
                    $category_name = '';
                    
                    switch ($current_category) {
                        case 'regular': $category_name = 'Регулярные услуги'; break;
                        case 'deep': $category_name = 'Глубокие чистки'; break;
                        case 'special': $category_name = 'Специальные услуги'; break;
                    }
            ?>
                <div class="service-category"><?= $category_name ?></div>
            <?php endif; ?>
            
            <div class="service-item">
                <label>
                    <input type="checkbox" name="services[]" value="<?= $service['id'] ?>">
                    <?= sanitize($service['name']) ?> - <?= $service['price'] ?> руб.
                    (<?= floor($service['duration']/60) ?> ч. <?= $service['duration']%60 ?> мин.)
                </label>
                <p><em><?= sanitize($service['description']) ?></em></p>
            </div>
            <?php endforeach; ?>
        </div>
        
        <button type="submit" name="create_order">Оформить заказ</button>
    </form>
    
    <h2>История заказов</h2>
    <?php if (empty($orders)): ?>
        <p>У вас пока нет заказов</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Дата уборки</th>
                    <th>Адрес</th>
                    <th>Услуги</th>
                    <th>Стоимость</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): 
                    $status_class = 'status-' . str_replace(' ', '_', $order['status']);
                ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= date('d.m.Y H:i', strtotime($order['order_date'])) ?></td>
                        <td><?= sanitize($order['address']) ?></td>
                        <td>
                            <?php
                            $stmt = $pdo->prepare("
                                SELECT s.name 
                                FROM order_items oi 
                                JOIN services s ON oi.service_id = s.id 
                                WHERE oi.order_id = ?
                            ");
                            $stmt->execute([$order['id']]);
                            $items = $stmt->fetchAll();
                            echo implode(', ', array_column($items, 'name'));
                            ?>
                        </td>
                        <td><?= $order['total_price'] ?> руб.</td>
                        <td class="<?= $status_class ?>">
                            <?php 
                            $statuses = [
                                'new' => 'Новый',
                                'confirmed' => 'Подтвержден',
                                'in_progress' => 'В работе',
                                'completed' => 'Завершен',
                                'cancelled' => 'Отменен'
                            ];
                            echo $statuses[$order['status']] ?? $order['status'];
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>