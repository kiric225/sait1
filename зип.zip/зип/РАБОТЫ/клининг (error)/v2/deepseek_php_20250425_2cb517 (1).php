<?php
require_once 'config.php';

// Если пользователь уже авторизован, перенаправляем его
if (isLoggedIn()) {
    redirect(isAdmin() ? 'admin.php' : 'orders.php');
}

$errors = [];
$formData = [
    'full_name' => '',
    'phone' => '',
    'email' => '',
    'login' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $formData = [
        'full_name' => sanitize($_POST['full_name'] ?? ''),
        'phone' => sanitize($_POST['phone'] ?? ''),
        'email' => sanitize($_POST['email'] ?? ''),
        'login' => sanitize($_POST['login'] ?? '')
    ];
    
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Валидация
    if (empty($formData['full_name'])) {
        $errors[] = 'ФИО обязательно для заполнения';
    }
    
    if (empty($formData['phone']) || !validatePhone($formData['phone'])) {
        $errors[] = 'Телефон должен быть в формате (XXX)-XXX-XX-XX';
    }
    
    if (empty($formData['email']) || !filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Введите корректный email';
    }
    
    if (empty($formData['login'])) {
        $errors[] = 'Логин обязателен для заполнения';
    }
    
    if (strlen($password) < MIN_PASSWORD_LENGTH) {
        $errors[] = 'Пароль должен содержать не менее ' . MIN_PASSWORD_LENGTH . ' символов';
    }
    
    if ($password !== $confirm_password) {
        $errors[] = 'Пароли не совпадают';
    }
    
    if (empty($errors)) {
        try {
            $pdo = getDBConnection();
            
            // Проверка уникальности email и логина
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? OR login = ?");
            $stmt->execute([$formData['email'], $formData['login']]);
            
            if ($stmt->fetchColumn() > 0) {
                $errors[] = 'Пользователь с таким email или логином уже зарегистрирован';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt = $pdo->prepare("
                    INSERT INTO users (full_name, phone, email, login, password) 
                    VALUES (?, ?, ?, ?, ?)
                ");
                
                $stmt->execute([
                    $formData['full_name'],
                    $formData['phone'],
                    $formData['email'],
                    $formData['login'],
                    $hashed_password
                ]);
                
                $_SESSION['user_id'] = $pdo->lastInsertId();
                $_SESSION['is_admin'] = false;
                $_SESSION['full_name'] = $formData['full_name'];
                
                redirect('orders.php');
            }
        } catch (PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            $errors[] = 'Ошибка при регистрации. Пожалуйста, попробуйте позже.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Клининговая компания</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 15px; }
        .error ul { margin: 0; padding-left: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input { width: 100%; padding: 8px; box-sizing: border-box; }
        button { padding: 10px 15px; background: #28a745; color: white; border: none; cursor: pointer; }
        button:hover { background: #218838; }
    </style>
</head>
<body>
    <h1>Регистрация</h1>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST" novalidate>
        <div class="form-group">
            <label for="full_name">ФИО:</label>
            <input type="text" id="full_name" name="full_name" value="<?= $formData['full_name'] ?>" required>
        </div>
        
        <div class="form-group">
            <label for="phone">Телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" id="phone" name="phone" value="<?= $formData['phone'] ?>" 
                   placeholder="(XXX)-XXX-XX-XX" required>
        </div>
        
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= $formData['email'] ?>" required>
        </div>
        
        <div class="form-group">
            <label for="login">Логин:</label>
            <input type="text" id="login" name="login" value="<?= $formData['login'] ?>" required>
        </div>
        
        <div class="form-group">
            <label for="password">Пароль (минимум <?= MIN_PASSWORD_LENGTH ?> символов):</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <div class="form-group">
            <label for="confirm_password">Подтверждение пароля:</label>
            <input type="password" id="confirm_password" name="confirm_password" required>
        </div>
        
        <button type="submit">Зарегистрироваться</button>
    </form>
    
    <p style="margin-top: 20px;">
        Уже зарегистрированы? <a href="login.php">Войти в систему</a>
    </p>
</body>
</html>