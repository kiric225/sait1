<?php
require_once 'config.php';

// Проверка прав администратора
if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$errors = [];
$success = '';

try {
    $pdo = getDBConnection();
    
    // Получение всех заказов с информацией о клиентах
    $orders = $pdo->query("
        SELECT o.*, u.full_name, u.email, u.phone as user_phone
        FROM orders o
        JOIN users u ON o.user_id = u.id
        ORDER BY o.order_date DESC
    ")->fetchAll();
    
    // Обновление статуса заказа
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
        $order_id = (int)$_POST['order_id'];
        $status = sanitize($_POST['status']);
        
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $order_id]);
        
        $success = 'Статус заказа успешно обновлен';
        
        // Обновляем список заказов
        $orders = $pdo->query("
            SELECT o.*, u.full_name, u.email, u.phone as user_phone
            FROM orders o
            JOIN users u ON o.user_id = u.id
            ORDER BY o.order_date DESC
        ")->fetchAll();
    }
} catch (PDOException $e) {
    error_log("Admin panel error: " . $e->getMessage());
    $errors[] = 'Ошибка при загрузке данных. Пожалуйста, попробуйте позже.';
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Клининговая компания</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 15px; }
        .error ul, .success ul { margin: 0; padding-left: 20px; }
        .success { color: green; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        button { padding: 5px 10px; background: #007bff; color: white; border: none; cursor: pointer; }
        button:hover { background: #0056b3; }
        select { padding: 5px; }
        .status-form { display: flex; align-items: center; gap: 10px; }
        .status-new { color: #007bff; }
        .status-confirmed { color: #17a2b8; }
        .status-in_progress { color: #ffc107; }
        .status-completed { color: #28a745; }
        .status-cancelled { color: #dc3545; }
    </style>
</head>
<body>
    <h1>Панель администратора</h1>
    <p>Вы вошли как администратор. <a href="logout.php">Выйти</a></p>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?= $error ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>
    
    <h2>Все заказы</h2>
    <?php if (empty($orders)): ?>
        <p>Нет заказов</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Клиент</th>
                    <th>Контакты</th>
                    <th>Адрес</th>
                    <th>Дата уборки</th>
                    <th>Услуги</th>
                    <th>Стоимость</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): 
                    $status_class = 'status-' . str_replace(' ', '_', $order['status']);
                ?>
                    <tr>
                        <td><?= $order['id'] ?></td>
                        <td><?= sanitize($order['full_name']) ?></td>
                        <td>
                            <?= sanitize($order['user_phone']) ?><br>
                            <?= sanitize($order['email']) ?>
                        </td>
                        <td><?= sanitize($order['address']) ?></td>
                        <td><?= date('d.m.Y H:i', strtotime($order['order_date'])) ?></td>
                        <td>
                            <?php
                            $stmt = $pdo->prepare("
                                SELECT s.name 
                                FROM order_items oi 
                                JOIN services s ON oi.service_id = s.id 
                                WHERE oi.order_id = ?
                            ");
                            $stmt->execute([$order['id']]);
                            $items = $stmt->fetchAll();
                            echo implode(', ', array_column($items, 'name'));
                            ?>
                        </td>
                        <td><?= $order['total_price'] ?> руб.</td>
                        <td class="<?= $status_class ?>">
                            <?php 
                            $statuses = [
                                'new' => 'Новый',
                                'confirmed' => 'Подтвержден',
                                'in_progress' => 'В работе',
                                'completed' => 'Завершен',
                                'cancelled' => 'Отменен'
                            ];
                            echo $statuses[$order['status']] ?? $order['status'];
                            ?>
                        </td>
                        <td>
                            <form method="POST" class="status-form">
                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                <select name="status">
                                    <?php foreach ($statuses as $key => $value): ?>
                                        <option value="<?= $key ?>" <?= $order['status'] === $key ? 'selected' : '' ?>>
                                            <?= $value ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="submit" name="update_status">Обновить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>