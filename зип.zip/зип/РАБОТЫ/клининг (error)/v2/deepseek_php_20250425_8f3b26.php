<?php
require_once 'config.php';

// Очищаем сессию
$_SESSION = [];
session_destroy();

// Перенаправляем на страницу входа
redirect('login.php');
?>