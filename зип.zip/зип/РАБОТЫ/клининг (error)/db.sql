-- Создаем базу данных
CREATE DATABASE IF NOT EXISTS cleaning_company;
USE cleaning_company;

-- Таблица пользователей
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL COMMENT 'ФИО',
    phone VARCHAR(20) NOT NULL COMMENT 'Телефон',
    email VARCHAR(100) NOT NULL COMMENT 'Email',
    login VARCHAR(50) NOT NULL COMMENT 'Логин',
    password VARCHAR(255) NOT NULL COMMENT 'Пароль',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата регистрации'
);

-- Таблица услуг
CREATE TABLE IF NOT EXISTS services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL COMMENT 'Название услуги',
    description TEXT COMMENT 'Описание услуги',
    price DECIMAL(10, 2) NOT NULL COMMENT 'Цена'
);

-- Таблица заказов
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL COMMENT 'ID клиента',
    address TEXT NOT NULL COMMENT 'Адрес уборки',
    phone VARCHAR(20) NOT NULL COMMENT 'Контактный телефон',
    order_date DATETIME NOT NULL COMMENT 'Дата и время уборки',
    status ENUM('new', 'processing', 'in_progress', 'completed', 'cancelled') DEFAULT 'new' COMMENT 'Статус заказа',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP COMMENT 'Дата создания заказа',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Таблица элементов заказа
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL COMMENT 'ID заказа',
    service_id INT NOT NULL COMMENT 'ID услуги',
    quantity INT NOT NULL DEFAULT 1 COMMENT 'Количество',
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES services(id)
);

-- Добавляем администратора (логин: admin, пароль: delivery123)
INSERT INTO users (full_name, phone, email, login, password) 
VALUES ('Администратор', '(123)-456-78-90', 'admin@cleaning.ru', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Добавляем услуги клининга
INSERT INTO services (name, description, price) VALUES 
('Генеральная уборка', 'Полная уборка всей квартиры или дома', 5000.00),
('Мытье окон', 'Чистка всех окон в помещении', 2000.00),
('Химчистка ковров', 'Профессиональная чистка ковровых покрытий', 3000.00),
('Уборка после ремонта', 'Уборка строительного мусора и пыли после ремонта', 8000.00),
('Еженедельная уборка', 'Поддерживающая уборка 1 раз в неделю', 3500.00);