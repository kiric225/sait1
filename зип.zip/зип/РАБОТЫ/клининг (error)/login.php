<?php
session_start();
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);
    
    // Проверка администратора
    if ($login === 'admin' && $password === 'delivery123') {
        $_SESSION['user_id'] = 0;
        $_SESSION['is_admin'] = true;
        $_SESSION['full_name'] = 'Администратор';
        header('Location: admin.php');
        exit;
    }
    
    // Проверка обычного пользователя
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['is_admin'] = false;
        $_SESSION['full_name'] = $user['full_name'];
        header('Location: orders.php');
        exit;
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Вход в систему</title>
</head>
<body>
    <h1>Вход в систему</h1>
    <?php if ($error): ?>
        <p style="color: red;"><?= $error ?></p>
    <?php endif; ?>
    <form method="POST">
        <div>
            <label>Логин:</label>
            <input type="text" name="login" required>
        </div>
        <div>
            <label>Пароль:</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit">Войти</button>
    </form>
    <p>Ещё не зарегистрированы? <a href="register.php">Зарегистрироваться</a></p>
</body>
</html>