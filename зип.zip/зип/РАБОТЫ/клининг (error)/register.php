<?php
session_start();
require_once 'config.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $login = trim($_POST['login']);
    $password = trim($_POST['password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Валидация
    if (empty($full_name)) $errors[] = 'ФИО обязательно для заполнения';
    if (empty($phone) || !preg_match('/^\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) $errors[] = 'Телефон должен быть в формате (XXX)-XXX-XX-XX';
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Введите корректный email';
    if (empty($login)) $errors[] = 'Логин обязателен для заполнения';
    if (empty($password) || strlen($password) < 6) $errors[] = 'Пароль должен содержать не менее 6 символов';
    if ($password !== $confirm_password) $errors[] = 'Пароли не совпадают';
    
    // Проверка уникальности email и логина
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ? OR login = ?");
    $stmt->execute([$email, $login]);
    if ($stmt->fetchColumn() > 0) {
        $errors[] = 'Пользователь с таким email или логином уже зарегистрирован';
    }
    
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (full_name, phone, email, login, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$full_name, $phone, $email, $login, $hashed_password]);
        
        $_SESSION['user_id'] = $pdo->lastInsertId();
        $_SESSION['is_admin'] = false;
        $_SESSION['full_name'] = $full_name;
        header('Location: orders.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
</head>
<body>
    <h1>Регистрация</h1>
    <?php if (!empty($errors)): ?>
        <ul style="color: red;">
            <?php foreach ($errors as $error): ?>
                <li><?= $error ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
    <form method="POST">
        <div>
            <label>ФИО:</label>
            <input type="text" name="full_name" required>
        </div>
        <div>
            <label>Телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" name="phone" placeholder="(XXX)-XXX-XX-XX" required>
        </div>
        <div>
            <label>Email:</label>
            <input type="email" name="email" required>
        </div>
        <div>
            <label>Логин:</label>
            <input type="text" name="login" required>
        </div>
        <div>
            <label>Пароль (минимум 6 символов):</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Подтверждение пароля:</label>
            <input type="password" name="confirm_password" required>
        </div>
        <button type="submit">Зарегистрироваться</button>
    </form>
    <p>Уже зарегистрированы? <a href="login.php">Войти</a></p>
</body>
</html>