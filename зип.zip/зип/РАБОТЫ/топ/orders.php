<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$errors = [];
$success = false;

// Получаем список ресторанов
$restaurants = $pdo->query("SELECT * FROM restaurants")->fetchAll(PDO::FETCH_ASSOC);

// Получаем список заказов пользователя
$user_orders = [];
try {
    $stmt = $pdo->prepare("
        SELECT o.*, GROUP_CONCAT(d.name SEPARATOR ', ') as dishes 
        FROM orders o
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN dishes d ON oi.dish_id = d.dish_id
        WHERE o.user_id = ?
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $user_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Ошибка при получении списка заказов: " . $e->getMessage();
}

// Обработка создания нового заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_order'])) {
    $delivery_address = trim($_POST['delivery_address']);
    $contact_phone = trim($_POST['contact_phone']);
    $delivery_time = trim($_POST['delivery_time']);
    $restaurant_id = (int)$_POST['restaurant_id'];
    $dishes = $_POST['dishes'] ?? [];

    // Валидация данных
    if (empty($delivery_address)) {
        $errors[] = "Адрес доставки обязателен для заполнения";
    }

    if (empty($contact_phone) || !preg_match('/^\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $contact_phone)) {
        $errors[] = "Телефон должен быть в формате (XXX)-XXX-XX-XX";
    }

    if (empty($delivery_time)) {
        $errors[] = "Укажите дату и время доставки";
    }

    if (empty($restaurant_id)) {
        $errors[] = "Выберите ресторан";
    }

    if (empty($dishes)) {
        $errors[] = "Выберите хотя бы одно блюдо";
    }

    // Если ошибок нет, создаем заказ
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Создаем заказ
            $stmt = $pdo->prepare("
                INSERT INTO orders (user_id, delivery_address, contact_phone, delivery_time, status)
                VALUES (?, ?, ?, ?, 'new')
            ");
            $stmt->execute([
                $_SESSION['user_id'],
                $delivery_address,
                $contact_phone,
                $delivery_time
            ]);
            $order_id = $pdo->lastInsertId();

            // Добавляем блюда в заказ
            foreach ($dishes as $dish_id => $quantity) {
                if ($quantity > 0) {
                    // Получаем цену блюда
                    $stmt = $pdo->prepare("SELECT price FROM dishes WHERE dish_id = ?");
                    $stmt->execute([$dish_id]);
                    $dish = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($dish) {
                        $stmt = $pdo->prepare("
                            INSERT INTO order_items (order_id, dish_id, quantity, price)
                            VALUES (?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $order_id,
                            $dish_id,
                            $quantity,
                            $dish['price']
                        ]);
                    }
                }
            }

            $pdo->commit();
            $success = true;
            redirect('orders.php');
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Ошибка при создании заказа: " . $e->getMessage();
        }
    }
}

// Получаем список блюд для выбранного ресторана (AJAX)
if (isset($_GET['restaurant_id'])) {
    $restaurant_id = (int)$_GET['restaurant_id'];
    $dishes = $pdo->prepare("SELECT * FROM dishes WHERE restaurant_id = ?");
    $dishes->execute([$restaurant_id]);
    $dishes_data = $dishes->fetchAll(PDO::FETCH_ASSOC);
    
    header('Content-Type: application/json');
    echo json_encode($dishes_data);
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Мои заказы - Быстро и Вкусно</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .error { color: red; }
        .success { color: green; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input, select { padding: 8px; box-sizing: border-box; }
        button { padding: 10px 15px; background: #4CAF50; color: white; border: none; cursor: pointer; }
        button:hover { background: #45a049; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .order-status-new { color: blue; }
        .order-status-preparing { color: orange; }
        .order-status-delivering { color: purple; }
        .order-status-completed { color: green; }
        .order-status-canceled { color: red; }
        .dishes-list { display: flex; flex-wrap: wrap; gap: 20px; }
        .dish-item { border: 1px solid #ddd; padding: 15px; width: 200px; }
        .dish-item h3 { margin-top: 0; }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <h1>Мои заказы</h1>
    <p>Добро пожаловать, <?= htmlspecialchars($_SESSION['full_name']) ?>! <a href="logout.php">Выйти</a></p>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="success">
            <p>Заказ успешно создан!</p>
        </div>
    <?php endif; ?>
    
    <h2>История заказов</h2>
    <?php if (empty($user_orders)): ?>
        <p>У вас пока нет заказов.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Дата создания</th>
                    <th>Адрес доставки</th>
                    <th>Телефон</th>
                    <th>Время доставки</th>
                    <th>Блюда</th>
                    <th>Статус</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($user_orders as $order): ?>
                    <tr>
                        <td><?= $order['order_id'] ?></td>
                        <td><?= $order['created_at'] ?></td>
                        <td><?= htmlspecialchars($order['delivery_address']) ?></td>
                        <td><?= htmlspecialchars($order['contact_phone']) ?></td>
                        <td><?= $order['delivery_time'] ?></td>
                        <td><?= htmlspecialchars($order['dishes']) ?></td>
                        <td class="order-status-<?= $order['status'] ?>">
                            <?php 
                                $statuses = [
                                    'new' => 'Новый',
                                    'preparing' => 'Готовится',
                                    'delivering' => 'Доставляется',
                                    'completed' => 'Завершен',
                                    'canceled' => 'Отменен'
                                ];
                                echo $statuses[$order['status']];
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
    
    <h2>Создать новый заказ</h2>
    <form method="post" id="order-form">
        <div class="form-group">
            <label for="delivery_address">Адрес доставки:</label>
            <input type="text" id="delivery_address" name="delivery_address" required style="width: 100%;">
        </div>
        
        <div class="form-group">
            <label for="contact_phone">Контактный телефон (формат (XXX)-XXX-XX-XX):</label>
            <input type="text" id="contact_phone" name="contact_phone" pattern="\(\d{3}\)-\d{3}-\d{2}-\d{2}" required>
        </div>
        
        <div class="form-group">
            <label for="delivery_time">Дата и время доставки:</label>
            <input type="datetime-local" id="delivery_time" name="delivery_time" required>
        </div>
        
        <div class="form-group">
            <label for="restaurant_id">Ресторан:</label>
            <select id="restaurant_id" name="restaurant_id" required>
                <option value="">Выберите ресторан</option>
                <?php foreach ($restaurants as $restaurant): ?>
                    <option value="<?= $restaurant['restaurant_id'] ?>"><?= htmlspecialchars($restaurant['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label>Блюда:</label>
            <div id="dishes-container">
                <p>Выберите ресторан, чтобы увидеть доступные блюда</p>
            </div>
        </div>
        
        <button type="submit" name="create_order">Оформить заказ</button>
    </form>
    
    <script>
        $(document).ready(function() {
            // Загрузка блюд при выборе ресторана
            $('#restaurant_id').change(function() {
                var restaurant_id = $(this).val();
                if (restaurant_id) {
                    $.get('orders.php', {restaurant_id: restaurant_id}, function(data) {
                        var dishesContainer = $('#dishes-container');
                        dishesContainer.empty();
                        
                        if (data.length > 0) {
                            dishesContainer.append('<div class="dishes-list"></div>');
                            var dishesList = dishesContainer.find('.dishes-list');
                            
                            $.each(data, function(index, dish) {
                                var dishHtml = `
                                    <div class="dish-item">
                                        <h3>${dish.name}</h3>
                                        <p>${dish.description || 'Описание отсутствует'}</p>
                                        <p>Цена: ${dish.price} руб.</p>
                                        <label>
                                            Количество:
                                            <input type="number" name="dishes[${dish.dish_id}]" min="0" value="0" style="width: 60px;">
                                        </label>
                                    </div>
                                `;
                                dishesList.append(dishHtml);
                            });
                        } else {
                            dishesContainer.append('<p>В этом ресторане пока нет блюд</p>');
                        }
                    });
                } else {
                    $('#dishes-container').html('<p>Выберите ресторан, чтобы увидеть доступные блюда</p>');
                }
            });
        });
    </script>
</body>
</html>