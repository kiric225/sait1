<?php
require_once 'config.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$errors = [];

// Обработка изменения статуса заказа
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = $_POST['status'];

    try {
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
        $stmt->execute([$status, $order_id]);
    } catch (PDOException $e) {
        $errors[] = "Ошибка при обновлении статуса: " . $e->getMessage();
    }
}

// Получаем список всех заказов
$orders = [];
try {
    $stmt = $pdo->query("
        SELECT o.*, u.full_name, u.phone as customer_phone, u.email,
               GROUP_CONCAT(CONCAT(d.name, ' (', oi.quantity, 'x)', ' - ', oi.price * oi.quantity, ' руб.') SEPARATOR '<br>') as dishes_details,
               SUM(oi.price * oi.quantity) as total_price
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        JOIN order_items oi ON o.order_id = oi.order_id
        JOIN dishes d ON oi.dish_id = d.dish_id
        GROUP BY o.order_id
        ORDER BY o.created_at DESC
    ");
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $errors[] = "Ошибка при получении списка заказов: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Панель администратора - Быстро и Вкусно</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1200px; margin: 0 auto; padding: 20px; }
        .error { color: red; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .order-status-new { color: blue; }
        .order-status-preparing { color: orange; }
        .order-status-delivering { color: purple; }
        .order-status-completed { color: green; }
        .order-status-canceled { color: red; }
        form { display: inline; }
        select, button { padding: 5px; }
    </style>
</head>
<body>
    <h1>Панель администратора</h1>
    <p>Добро пожаловать, администратор! <a href="logout.php">Выйти</a></p>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <h2>Все заказы</h2>
    <?php if (empty($orders)): ?>
        <p>Нет заказов для отображения.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Заказчик</th>
                    <th>Контактные данные</th>
                    <th>Адрес доставки</th>
                    <th>Время доставки</th>
                    <th>Состав заказа</th>
                    <th>Сумма</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td><?= $order['order_id'] ?></td>
                        <td><?= htmlspecialchars($order['full_name']) ?></td>
                        <td>
                            Телефон: <?= htmlspecialchars($order['customer_phone']) ?><br>
                            Email: <?= htmlspecialchars($order['email']) ?>
                        </td>
                        <td><?= htmlspecialchars($order['delivery_address']) ?></td>
                        <td><?= $order['delivery_time'] ?></td>
                        <td><?= $order['dishes_details'] ?></td>
                        <td><?= $order['total_price'] ?> руб.</td>
                        <td class="order-status-<?= $order['status'] ?>">
                            <?php 
                                $statuses = [
                                    'new' => 'Новый',
                                    'preparing' => 'Готовится',
                                    'delivering' => 'Доставляется',
                                    'completed' => 'Завершен',
                                    'canceled' => 'Отменен'
                                ];
                                echo $statuses[$order['status']];
                            ?>
                        </td>
                        <td>
                            <form method="post">
                                <input type="hidden" name="order_id" value="<?= $order['order_id'] ?>">
                                <select name="status">
                                    <option value="new" <?= $order['status'] === 'new' ? 'selected' : '' ?>>Новый</option>
                                    <option value="preparing" <?= $order['status'] === 'preparing' ? 'selected' : '' ?>>Готовится</option>
                                    <option value="delivering" <?= $order['status'] === 'delivering' ? 'selected' : '' ?>>Доставляется</option>
                                    <option value="completed" <?= $order['status'] === 'completed' ? 'selected' : '' ?>>Завершен</option>
                                    <option value="canceled" <?= $order['status'] === 'canceled' ? 'selected' : '' ?>>Отменен</option>
                                </select>
                                <button type="submit" name="update_status">Обновить</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</body>
</html>