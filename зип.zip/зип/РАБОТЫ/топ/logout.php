<?php
require_once 'config.php';

// Уничтожаем сессию
session_destroy();

// Перенаправляем на страницу авторизации
redirect('login.php');
?>