<?php
// Перенаправляем на страницу входа по умолчанию
header('Location: login.php');
exit();
?> 