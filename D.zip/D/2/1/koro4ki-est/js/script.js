document.addEventListener('DOMContentLoaded', function() {
    // Маска для телефона
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            e.target.value = !x[2] ? '+7' + x[1] : '+7(' + x[2] + ')' + (x[3] ? '-' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
        });
    }
    
    // Валидация даты
    const dateInput = document.getElementById('start_date');
    if (dateInput) {
        dateInput.addEventListener('blur', function(e) {
            const value = e.target.value;
            if (value && !/^\d{2}\.\d{2}\.\d{4}$/.test(value)) {
                alert('Пожалуйста, введите дату в формате ДД.ММ.ГГГГ');
                e.target.focus();
            }
        });
    }
    
    // Анимация при загрузке
    const container = document.querySelector('.container');
    if (container) {
        container.style.opacity = 0;
        setTimeout(() => {
            container.style.transition = 'opacity 0.5s ease';
            container.style.opacity = 1;
        }, 100);
    }
});