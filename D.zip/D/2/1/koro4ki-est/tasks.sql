DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` int NOT NULL,
  `course_name` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Новый',
  `feedback` text,
  PRIMARY KEY (`id`),
  FOREIGN KEY (`login`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;