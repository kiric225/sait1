UPDATE `users` SET 
`FIO` = 'Администратор Системы', 
`phone` = '+7(999)-999-99-99', 
`mail` = 'admin@koro4ki.est', 
`password` = 'education', 
`login` = 'admin' 
WHERE `id` = 1;