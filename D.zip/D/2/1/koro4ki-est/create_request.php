<?php
require 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

$courses = [
    'Основы алгоритмизации и программирования',
    'Основы веб-дизайна',
    'Основы проектирования баз данных'
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $courseName = $_POST['course_name'] ?? '';
    $startDate = $_POST['start_date'] ?? '';
    $paymentMethod = $_POST['payment_method'] ?? '';
    
    if (in_array($courseName, $courses) && validateDate($startDate, 'd.m.Y') && 
        in_array($paymentMethod, ['Наличными', 'Перевод на банковский счет'])) {
        
        global $pdo;
        $stmt = $pdo->prepare("INSERT INTO tasks (login, course_name, start_date, payment_method) VALUES (?, ?, ?, ?)");
        $dateFormatted = DateTime::createFromFormat('d.m.Y', $startDate)->format('Y-m-d');
        
        if ($stmt->execute([$_SESSION['user']['id'], $courseName, $dateFormatted, $paymentMethod])) {
            header('Location: dashboard.php?success=1');
            exit;
        } else {
            $error = "Ошибка при создании заявки";
        }
    } else {
        $error = "Проверьте правильность введенных данных";
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка - Корочки.есть</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Новая заявка на обучение</h1>
        <?php if (isset($error)): ?>
            <div class="alert error"><?= $error ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="course_name">Курс:</label>
                <select id="course_name" name="course_name" required>
                    <option value="">-- Выберите курс --</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?= htmlspecialchars($course) ?>"><?= htmlspecialchars($course) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="start_date">Желаемая дата начала (ДД.ММ.ГГГГ):</label>
                <input type="text" id="start_date" name="start_date" required 
                       placeholder="дд.мм.гггг" pattern="\d{2}\.\d{2}\.\d{4}">
            </div>
            <div class="form-group">
                <label>Способ оплаты:</label>
                <div class="radio-group">
                    <label><input type="radio" name="payment_method" value="Наличными" required> Наличными</label>
                    <label><input type="radio" name="payment_method" value="Перевод на банковский счет"> Перевод на банковский счет</label>
                </div>
            </div>
            <button type="submit" class="btn">Отправить заявку</button>
        </form>
        <a href="dashboard.php" class="btn back">Назад</a>
    </div>
    
    <script src="js/script.js"></script>
</body>
</html>