<?php
require 'config.php';

function isAdmin() {
    return isset($_SESSION['user']) && $_SESSION['user']['isAdmin'] === 'Администратор';
}

function isLoggedIn() {
    return isset($_SESSION['user']);
}

function validateDate($date, $format = 'd.m.Y') {
    $d = DateTime::createFromFormat($format, $date);
    return $d && $d->format($format) === $date;
}

function validatePhone($phone) {
    return preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone);
}

function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function validateLogin($login) {
    return preg_match('/^[а-яА-Я]{6,}$/u', $login);
}
?>