-- Добавляем таблицу для заявок на курсы
ALTER TABLE `tasks` RENAME TO `applications`;
ALTER TABLE `applications` 
  CHANGE `number_auto` `course_name` VARCHAR(100) NOT NULL,
  CHANGE `opisanie` `start_date` DATE NOT NULL,
  ADD `payment_method` VARCHAR(50) NOT NULL AFTER `start_date`,
  ADD `feedback` TEXT NULL AFTER `status`;

-- Добавляем поле для отзыва
ALTER TABLE `applications` ADD `feedback` TEXT NULL AFTER `status`;

-- Обновляем администратора
UPDATE `users` SET `login` = 'admin', `password` = 'education' WHERE `id` = 1;