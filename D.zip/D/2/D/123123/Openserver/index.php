<?php
include './connect.php';
if (!(isset($_COOKIE['login']))) {
    header('Location: ./auth.php');
}

if ($_COOKIE['isAdmin'] == 0) {
    include './add_requests.php';
    include './list_requets.php';
} else if ($_COOKIE['isAdmin'] == 1) {
    include './list_requets.php';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой не сам - Заявки</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            display: flex;
            justify-content: top;
            align-items: top;
            min-height: 100vh;
            margin: 0;
            padding: 20px;
        }
        .container {
            background: white;
            padding: 20px;
            border-radius: 5px;
            width: 100%;
            max-width: 400px;
        }
        h1 {
            font-size: 1.5em;
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        button {
            padding: 8px;
            background: #00ff1e;
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        .logout-link {
            text-align: center;
            margin-bottom: 20px;
        }
        .logout-link a {
            color: #00ff1e;
            text-decoration: none;
        }
        .error {
            color: red;
            text-align: center;
            margin: 10px 0;
        }
        .request {
            border: 1px solid #ccc;
            padding: 10px;
            margin: 10px 0;
            border-radius: 3px;
        }
        .request a {
            color: #007bff;
            margin-right: 10px;
            text-decoration: none;
        }
        .request a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logout-link">
            <a href="./logout.php">Выход</a>
        </div>

        <?php if ($_COOKIE['isAdmin'] == 0): ?>
            <h1>Создание заявки</h1>
            <form method="post">
                <input type="text" name="address" required placeholder="Адрес">
                <input type="text" name="phone" required placeholder="Телефон (XXX)-XXX-XX-XX">
                <input type="date" name="date" required placeholder="Дата услуги">
                <input type="text" name="model" required placeholder="Модель авто">
                <input type="text" name="marka" required placeholder="Марка авто">
                <button type="submit">Создать заявку</button>
            </form>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php foreach ($req as $key => $value): ?>
            <div class="request">
                <div><strong>ID:</strong> <?php echo htmlspecialchars($req[$key]['id']); ?></div>
                <div><strong>Адрес:</strong> <?php echo htmlspecialchars($req[$key]['address']); ?></div>
                <div><strong>Телефон:</strong> <?php echo htmlspecialchars($req[$key]['phone']); ?></div>
                <div><strong>Статус:</strong> <?php echo htmlspecialchars($req[$key]['status']); ?></div>
                <div><strong>Модель:</strong> <?php echo htmlspecialchars($req[$key]['model']); ?></div>
                <div><strong>Марка:</strong> <?php echo htmlspecialchars($req[$key]['marka']); ?></div>
                <?php if ($_COOKIE['isAdmin'] == 1): ?>
                    <div>
                        <a href="?acc=<?php echo $req[$key]['id']; ?>">Принять</a>
                        <a href="?noacc=<?php echo $req[$key]['id']; ?>">Отклонить</a>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>
</body>
</html>
