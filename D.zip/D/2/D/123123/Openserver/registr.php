<?php
// Подключение файлов для соединения с БД и обработки регистрации
include './connect.php';
include './registration.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <!-- Адаптивность для мобильных устройств -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой не сам - Регистрация</title>
    <style>
        /* Основные стили страницы */
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4; /* Светлый фон */
            display: flex;
            justify-content: top; /* Центрирование по горизонтали */
            align-items: top; /* Центрирование по вертикали */
            min-height: 100vh; /* Полная высота экрана */
            margin: 0;
        }
        /* Контейнер формы */
        .container {
            background: white;
            padding: 15px;
            border-radius: 5px;
            max-width: 280px; /* Компактная ширина */
        }
        /* Стили формы */
        form {
            display: flex;
            flex-direction: column;
            gap: 8px; /* Отступы между элементами */
        }
        /* Стили полей ввода */
        input {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 3px;
        }
        /* Стили кнопки */
        button {
            padding: 8px;
            background: #28a745; /* Зелёный цвет кнопки */
            color: white;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        /* Стили ссылки на авторизацию */
        .auth-link {
            text-align: center;
            margin-top: 8px;
        }
        .auth-link a {
            color: #28a745; /* Зелёный цвет ссылки */
            text-decoration: none;
        }
        /* Стили для ошибок */
        .error {
            color: red;
            text-align: center;
            margin-top: 8px;
        }
    </style>
</head>
<body>
    <!-- Контейнер для формы регистрации -->
    <div class="container">
        <!-- Форма отправки данных методом POST -->
        <form method="post">
            <input type="text" name="login" required placeholder="Логин">
            <input type="password" name="password" minlength="6" required placeholder="Пароль">
            <input type="text" name="fio" required placeholder="ФИО">
            <input type="text" name="phone" required placeholder="(XXX)-XXX-XX-XX">
            <input type="email" name="mail" required placeholder="Почта">
            <button type="submit">Зарегистрироваться</button>
        </form>
        <!-- Ссылка на страницу авторизации -->
        <div class="auth-link">
            <a href="./auth.php">Авторизация</a>
        </div>
        <!-- Вывод ошибки, если она есть -->
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
