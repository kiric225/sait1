<?php
$error = null;
if (isset($_POST['address'])) {
    $dbh = $conn->prepare('INSERT INTO `requests` (`address`, `phone`, `date`, `user`, `model`, `marka` ) VALUES (:address, :phone, :date, :user, :model, :marka)');
    $dbh->execute(['address' => $_POST['address'], 'phone' => $_POST['phone'], 'date' => $_POST['date'], 'user' => $_COOKIE['login'], 'model' => $_POST['model'], 'marka' => $_POST['marka']]);
}