-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 12 2025 г., 14:44
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `test`
--

-- --------------------------------------------------------

--
-- Структура таблицы `requests`
--

CREATE TABLE `requests` (
  `id` int NOT NULL,
  `address` text COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `date` text COLLATE utf8mb4_general_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'Новый',
  `user` varchar(30) COLLATE utf8mb4_general_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `requests`
--

INSERT INTO `requests` (`id`, `address`, `phone`, `date`, `status`, `user`) VALUES
(1, 'idwadw adwa dawd wad awdaw', '11111', '', 'Отклонено', ''),
(2, 'awdwadwa', 'wadwa', '', 'Отклонено', ''),
(3, 'dwadwa', 'wadwa', '', 'Новый', ''),
(4, 'qwe', '12321', '2025-04-10', 'Принято', ''),
(5, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(6, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(7, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(8, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(9, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(10, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(11, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(12, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(13, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(14, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(15, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(16, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(17, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(18, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(19, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(20, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(21, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(22, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(23, 'wadwa', '21231', '2025-04-17', 'Новый', ''),
(24, 'wa', '21', '2025-03-31', 'Новый', ''),
(25, 'wa', '21', '2025-03-31', 'Новый', ''),
(26, 'wa', '21', '2025-03-31', 'Новый', ''),
(27, 'wa', '21', '2025-03-31', 'Новый', ''),
(28, 'wa', '21', '2025-03-31', 'Новый', ''),
(29, 'wa', '21', '2025-03-31', 'Новый', ''),
(30, 'wa', '21', '2025-03-31', 'Новый', ''),
(31, '123', '121', '2025-04-01', 'Новый', ''),
(32, 'wa', '1', '2025-04-01', 'Новый', ''),
(33, 'wa', '1', '2025-04-01', 'Новый', ''),
(34, 'wa', '21231', '2025-04-02', 'Новый', ''),
(35, 'y', '000', '55555-05-05', 'Новый', 'wadwaawawdwa'),
(36, 'u', '44', '0022-02-22', 'Новый', 'wadwaawawdwa'),
(37, 'u', '44', '0022-02-22', 'Отклонено', 'wadwaawawdwa'),
(38, 'qwe', '12321', '0321-03-12', 'Принято', 'wadwaawawdwa');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `login` varchar(20) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(25) COLLATE utf8mb4_general_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `mail` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `fio` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `isAdmin` int NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `phone`, `mail`, `fio`, `isAdmin`) VALUES
(1, 'qwe', 'qwe', '', '', '', 0),
(2, 'qwe', 'qwe', '', '', '', 0),
(3, 'qweqwe', 'qweqwe', '', '', '', 0),
(4, 'qw', 'qw', '12321', '@wqwe', 'qwe', 0),
(5, 's', 'sssssss', '12321', 's@s', 's', 0),
(6, 'awdwa', 'awdawdwa', '212321321', 'Saadw@dwadwa', 'awdwadwa awdawd wad wa', 0),
(7, 'asdwadwad', 'wadwaaw', '221123', 'wadwadaw@wad', 'dwadwad', 0),
(8, 'w', 'qweqwe', '1', 'w@w', 'w', 0),
(9, 'wadwaawawdwa', 'qweqwe', '21321', 'aw2@wqaadwada', 'awdwadaw', 0),
(10, 'adminka', 'password', '', '', '', 1);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
