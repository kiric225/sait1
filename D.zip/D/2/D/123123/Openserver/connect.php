<?php
$conn = new PDO('mysql:host=localhost;dbname=333','root','');