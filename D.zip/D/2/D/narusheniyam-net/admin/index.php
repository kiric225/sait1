<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireAdmin(); // Требуем прав администратора

if (!isLoggedIn() || !isAdmin()) {
    redirect('../login.php');
}

$applications = getAllApplications();

require_once '../includes/header.php';
?>

<h2>Панель администратора</h2>

<?php if (empty($applications)): ?>
    <p>Нет заявлений</p>
<?php else: ?>
    <table class="applications-table admin">
        <thead>
            <tr>
                <th>№</th>
                <th>Пользователь</th>
                <th>Номер автомобиля</th>
                <th>Описание</th>
                <th>Дата создания</th>
                <th>Статус</th>
                <th>Действия</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($applications as $index => $app): ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($app['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($app['car_number']); ?></td>
                    <td><?php echo htmlspecialchars($app['description']); ?></td>
                    <td><?php echo date('d.m.Y H:i', strtotime($app['created_at'])); ?></td>
                    <td class="status-<?php echo $app['status']; ?>">
                        <?php 
                            switch($app['status']) {
                                case 'new': echo 'Новое'; break;
                                case 'confirmed': echo 'Подтверждено'; break;
                                case 'rejected': echo 'Отклонено'; break;
                            }
                        ?>
                    </td>
                    <td>
                        <?php if ($app['status'] != 'confirmed'): ?>
                            <form action="process_application.php" method="POST" class="inline-form">
                                <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                <input type="hidden" name="action" value="confirm">
                                <button type="submit" class="btn btn-small">Подтвердить</button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if ($app['status'] != 'rejected'): ?>
                            <form action="process_application.php" method="POST" class="inline-form">
                                <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="btn btn-small btn-danger">Отклонить</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php
require_once '../includes/footer.php';
?>