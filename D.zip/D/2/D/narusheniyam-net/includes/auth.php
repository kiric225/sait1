<?php
require_once 'config.php';

// Проверка авторизации для защищенных страниц
function requireAuth() {
    if (!isLoggedIn()) {
        $_SESSION['message'] = "Для доступа к этой странице необходимо авторизоваться";
        $_SESSION['message_type'] = 'error';
        redirect('login.php');
    }
}

// Проверка прав администратора
function requireAdmin() {
    requireAuth();
    
    if (!isAdmin()) {
        $_SESSION['message'] = "У вас недостаточно прав для доступа к этой странице";
        $_SESSION['message_type'] = 'error';
        redirect('applications.php');
    }
}

// Проверка CSRF-токена для форм
function verifyCsrfToken() {
    if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $_SESSION['message'] = "Ошибка безопасности. Пожалуйста, попробуйте еще раз.";
        $_SESSION['message_type'] = 'error';
        redirect($_SERVER['HTTP_REFERER'] ?? 'index.php');
    }
}

// Генерация CSRF-токена
function generateCsrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// Защита от XSS
function sanitizeInput($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Проверка email
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Проверка телефона (базовая валидация)
function validatePhone($phone) {
    return preg_match('/^\+?\d{10,15}$/', $phone);
}
?>