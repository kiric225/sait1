<?php
require_once 'config.php';

// Регистрация пользователя
function registerUser($username, $password, $full_name, $phone, $email) {
    global $pdo;
    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$username, $hashed_password, $full_name, $phone, $email]);
}

// Авторизация пользователя
function loginUser($username, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['is_admin'] = ($user['username'] === 'copp');
        return true;
    }
    
    return false;
}

// Создание заявления
function createApplication($user_id, $car_number, $description) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO applications (user_id, car_number, description) VALUES (?, ?, ?)");
    return $stmt->execute([$user_id, $car_number, $description]);
}

// Получение заявлений пользователя
function getUserApplications($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM applications WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

// Получение всех заявлений (для администратора)
function getAllApplications() {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT a.*, u.full_name FROM applications a JOIN users u ON a.user_id = u.id ORDER BY a.created_at DESC");
    $stmt->execute();
    return $stmt->fetchAll();
}

// Обновление статуса заявления
function updateApplicationStatus($application_id, $status) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
    return $stmt->execute([$status, $application_id]);
}
?>