<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect(isAdmin() ? '/admin/' : 'applications.php');
}

$errors = [];
$username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    if (empty($username)) $errors[] = "Логин обязателен";
    if (empty($password)) $errors[] = "Пароль обязателен";
    
    if (empty($errors)) {
        if (loginUser($username, $password)) {
            $_SESSION['message'] = "Вы успешно вошли в систему";
            $_SESSION['message_type'] = 'success';
            
            if (isAdmin()) {
                redirect('/admin/');
            } else {
                redirect('applications.php');
            }
        } else {
            $errors[] = "Неверный логин или пароль";
        }
    }
}

require_once 'includes/header.php';
?>

<h2>Вход в систему</h2>

<?php if (!empty($errors)): ?>
    <div class="alert error">
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" class="auth-form">
    <div class="form-group">
        <label for="username">Логин:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
    </div>
    
    <div class="form-group">
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
    </div>
    
    <button type="submit" class="btn">Войти</button>
</form>

<p>Нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>

<?php
require_once 'includes/footer.php';
?>