<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$errors = [];
$car_number = $description = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_number = trim($_POST['car_number']);
    $description = trim($_POST['description']);
    
    // Валидация
    if (empty($car_number)) $errors[] = "Номер автомобиля обязателен";
    if (empty($description)) $errors[] = "Описание нарушения обязательно";
    
    if (empty($errors)) {
        if (createApplication($_SESSION['user_id'], $car_number, $description)) {
            $_SESSION['message'] = "Заявление успешно создано";
            $_SESSION['message_type'] = 'success';
            redirect('applications.php');
        } else {
            $errors[] = "Ошибка при создании заявления";
        }
    }
}

require_once 'includes/header.php';
?>

<h2>Создание нового заявления</h2>

<?php if (!empty($errors)): ?>
    <div class="alert error">
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" class="application-form">
    <div class="form-group">
        <label for="car_number">Номер автомобиля:</label>
        <input type="text" id="car_number" name="car_number" value="<?php echo htmlspecialchars($car_number); ?>" required placeholder="А123БВ777">
    </div>
    
    <div class="form-group">
        <label for="description">Описание нарушения:</label>
        <textarea id="description" name="description" rows="5" required><?php echo htmlspecialchars($description); ?></textarea>
    </div>
    
    <button type="submit" class="btn">Отправить заявление</button>
    <a href="applications.php" class="btn btn-secondary">Отмена</a>
</form>

<?php
require_once 'includes/footer.php';
?>