<?php
session_start();
require_once 'config.php';

// Проверяем, авторизован ли пользователь
$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];

// Получаем список курсов
$courses = [];
$stmt = $pdo->query("SELECT * FROM courses WHERE is_active = 1");
if ($stmt) {
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Онлайн курсы</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h4 mb-0">Корочки.есть</h1>
                <nav>
                    <?php if ($isLoggedIn): ?>
                        <a href="applications.php" class="text-white mx-2">Мои заявки</a>
                        <?php if ($isAdmin): ?>
                            <a href="admin.php" class="text-white mx-2">Панель администратора</a>
                        <?php endif; ?>
                        <a href="logout.php" class="text-white mx-2">Выйти</a>
                    <?php else: ?>
                        <a href="login.php" class="text-white mx-2">Войти</a>
                        <a href="register.php" class="text-white mx-2">Регистрация</a>
                    <?php endif; ?>
                </nav>
            </div>
        </div>
    </header>

    <main class="container my-5">
        <section class="mb-5">
            <h2 class="text-center mb-4">Доступные курсы</h2>
            <div class="row">
                <?php foreach ($courses as $course): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card h-100">
                            <div class="card-body">
                                <h5 class="card-title"><?= htmlspecialchars($course['name']) ?></h5>
                                <p class="card-text"><?= htmlspecialchars($course['description']) ?></p>
                                <ul class="list-unstyled">
                                    <li><strong>Длительность:</strong> <?= $course['duration'] ?> дней</li>
                                    <li><strong>Стоимость:</strong> <?= number_format($course['price'], 2, '.', ' ') ?> ₽</li>
                                </ul>
                            </div>
                            <div class="card-footer bg-transparent">
                                <?php if ($isLoggedIn): ?>
                                    <a href="new_application.php?course_id=<?= $course['id'] ?>" class="btn btn-primary w-100">Подать заявку</a>
                                <?php else: ?>
                                    <button class="btn btn-primary w-100" disabled>Войдите, чтобы подать заявку</button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Корочки.есть - Все права защищены</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>