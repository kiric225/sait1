<?php
session_start();
require_once 'config.php';

// Проверка авторизации и прав администратора
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: login.php');
    exit;
}

// Получаем все заявки с информацией о пользователях и курсах
$stmt = $pdo->query("
    SELECT a.*, u.FIO as user_fio, u.phone as user_phone, u.mail as user_mail, 
           c.name as course_name, c.description as course_description
    FROM applications a
    JOIN users u ON a.user_id = u.id
    JOIN courses c ON a.course_id = c.id
    ORDER BY a.created_at DESC
");
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Обработка изменения статуса заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id'], $_POST['status'])) {
    $applicationId = (int)$_POST['application_id'];
    $status = $_POST['status'];
    
    if (in_array($status, ['new', 'in_progress', 'completed'])) {
        $stmt = $pdo->prepare("UPDATE applications SET status = ?, updated_at = NOW() WHERE id = ?");
        $stmt->execute([$status, $applicationId]);
        
        // Обновляем данные на странице
        foreach ($applications as &$app) {
            if ($app['id'] == $applicationId) {
                $app['status'] = $status;
                $app['updated_at'] = date('Y-m-d H:i:s');
                break;
            }
        }
        unset($app);
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Корочки.есть</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h4 mb-0">Корочки.есть - Панель администратора</h1>
                <nav>
                    <a href="index.php" class="text-white mx-2">Главная</a>
                    <a href="logout.php" class="text-white mx-2">Выйти</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="container my-5">
        <h2 class="text-center mb-4">Заявки на обучение</h2>
        
        <?php if (empty($applications)): ?>
            <div class="alert alert-info">
                Нет заявок на обучение.
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th>
                            <th>Курс</th>
                            <th>Пользователь</th>
                            <th>Контакты</th>
                            <th>Дата подачи</th>
                            <th>Желаемая дата</th>
                            <th>Способ оплаты</th>
                            <th>Статус</th>
                            <th>Действия</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><?= $app['id'] ?></td>
                                <td>
                                    <strong><?= htmlspecialchars($app['course_name']) ?></strong><br>
                                    <small><?= htmlspecialchars(mb_substr($app['course_description'], 0, 50)) ?>...</small>
                                </td>
                                <td><?= htmlspecialchars($app['user_fio']) ?></td>
                                <td>
                                    <small>Тел: <?= htmlspecialchars($app['user_phone']) ?><br>
                                    Email: <?= htmlspecialchars($app['user_mail']) ?></small>
                                </td>
                                <td><?= date('d.m.Y H:i', strtotime($app['created_at'])) ?></td>
                                <td><?= date('d.m.Y', strtotime($app['desired_start_date'])) ?></td>
                                <td><?= $app['payment_method'] === 'cash' ? 'Наличные' : 'Банковский перевод' ?></td>
                                <td>
                                    <span class="badge bg-<?= 
                                        $app['status'] === 'new' ? 'warning' : 
                                        ($app['status'] === 'in_progress' ? 'info' : 'success') 
                                    ?> text-dark">
                                        <?= 
                                            $app['status'] === 'new' ? 'Новая' : 
                                            ($app['status'] === 'in_progress' ? 'Идет обучение' : 'Обучение завершено') 
                                        ?>
                                    </span>
                                </td>
                                <td>
                                    <form method="post" class="d-flex">
                                        <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                        <select name="status" class="form-select form-select-sm me-2" onchange="this.form.submit()">
                                            <option value="new" <?= $app['status'] === 'new' ? 'selected' : '' ?>>Новая</option>
                                            <option value="in_progress" <?= $app['status'] === 'in_progress' ? 'selected' : '' ?>>Идет обучение</option>
                                            <option value="completed" <?= $app['status'] === 'completed' ? 'selected' : '' ?>>Обучение завершено</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Корочки.есть - Все права защищены</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>