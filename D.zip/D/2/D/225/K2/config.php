<?php
// Настройки базы данных
$dbHost = '127.0.0.1';
$dbName = 'site';
$dbUser = 'root';
$dbPass = '';

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Настройки сессии
session_start();
?>