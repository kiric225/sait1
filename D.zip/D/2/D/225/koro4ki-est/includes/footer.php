</main>
    <footer>
        <div class="container">
            <p>© 2025 Корочки.есть - система записи на онлайн курсы</p>
            <p>Телефон поддержки: +7 (800) 123-45-67</p>
        </div>
    </footer>
    <script src="/assets/js/main.js"></script>
    <?php if (isset($additional_scripts)): ?>
        <?php foreach ($additional_scripts as $script): ?>
            <script src="/assets/js/<?php echo $script; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>