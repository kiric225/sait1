<?php
require_once 'includes/auth_check.php';
requireGuest();

$title = 'Регистрация';
$additional_scripts = ['validation.js'];
require_once 'includes/header.php';

require_once 'database/db_connection.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $fio = trim($_POST['fio']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    // Валидация
    if (strlen($login) < 6 || !preg_match('/^[а-яА-ЯёЁ]+$/', $login)) {
        $errors['login'] = 'Логин должен содержать только кириллицу и быть не менее 6 символов';
    }

    if (!preg_match('/^[а-яА-ЯёЁ\s]+$/', $fio)) {
        $errors['fio'] = 'ФИО должно содержать только кириллицу и пробелы';
    }

    if (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $errors['phone'] = 'Телефон должен быть в формате +7(XXX)-XXX-XX-XX';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Некорректный email';
    }

    if (strlen($password) < 6) {
        $errors['password'] = 'Пароль должен быть не менее 6 символов';
    } elseif ($password !== $password_confirm) {
        $errors['password_confirm'] = 'Пароли не совпадают';
    }

    // Проверка уникальности логина
    $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
    $stmt->execute([$login]);
    if ($stmt->fetch()) {
        $errors['login'] = 'Этот логин уже занят';
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $stmt = $pdo->prepare("INSERT INTO users (login, fio, phone, email, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$login, $fio, $phone, $email, $hashed_password]);
        
        $_SESSION['success_message'] = 'Регистрация прошла успешно! Теперь вы можете войти.';
        header('Location: /login.php');
        exit();
    }
}
?>

<section class="auth-form">
    <h1>Регистрация</h1>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST" id="register-form">
        <div class="form-group">
            <label for="login">Логин (только кириллица)</label>
            <input type="text" id="login" name="login" required minlength="6" 
                   pattern="[а-яА-ЯёЁ]+" title="Только кириллические символы">
        </div>
        
        <div class="form-group">
            <label for="fio">ФИО</label>
            <input type="text" id="fio" name="fio" required 
                   pattern="[а-яА-ЯёЁ\s]+" title="Только кириллические символы и пробелы">
        </div>
        
        <div class="form-group">
            <label for="phone">Телефон</label>
            <input type="tel" id="phone" name="phone" required 
                   pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" placeholder="+7(XXX)-XXX-XX-XX">
        </div>
        
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
        
        <div class="form-group">
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" required minlength="6">
        </div>
        
        <div class="form-group">
            <label for="password_confirm">Подтвердите пароль</label>
            <input type="password" id="password_confirm" name="password_confirm" required minlength="6">
        </div>
        
        <button type="submit" class="btn">Зарегистрироваться</button>
    </form>
    
    <p>Уже зарегистрированы? <a href="/login.php">Войдите</a></p>
</section>

<?php require_once 'includes/footer.php'; ?>