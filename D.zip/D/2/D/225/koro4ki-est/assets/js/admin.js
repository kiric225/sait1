// Админ-панель
document.addEventListener('DOMContentLoaded', function() {
    // Изменение статуса заявки
    document.querySelectorAll('.status-select').forEach(select => {
        select.addEventListener('change', function() {
            const appId = this.getAttribute('data-app-id');
            const newStatus = this.value;
            
            fetch('/update_application_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    app_id: appId,
                    status: newStatus
                })
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    alert('Ошибка при обновлении статуса: ' + (data.message || 'Неизвестная ошибка'));
                    // Возвращаем предыдущее значение
                    this.value = this._previousValue;
                } else {
                    this._previousValue = this.value;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Произошла ошибка при обновлении статуса');
                this.value = this._previousValue;
            });
            
            // Сохраняем предыдущее значение на случай ошибки
            this._previousValue = this.value;
        });
    });
    
    // Просмотр отзыва
    document.querySelectorAll('.view-feedback').forEach(button => {
        button.addEventListener('click', function() {
            const feedback = this.getAttribute('data-feedback');
            const modal = document.getElementById('feedback-modal');
            const content = document.getElementById('feedback-content');
            
            content.textContent = feedback;
            modal.style.display = 'block';
        });
    });
    
    // Закрытие модального окна
    document.querySelector('.close').addEventListener('click', function() {
        document.getElementById('feedback-modal').style.display = 'none';
    });
    
    // Закрытие по клику вне окна
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('feedback-modal');
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
    
    // Фильтрация таблицы
    const filterInput = document.getElementById('table-filter');
    if (filterInput) {
        filterInput.addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('table tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }
});