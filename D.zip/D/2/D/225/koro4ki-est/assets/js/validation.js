// Валидация формы регистрации
document.addEventListener('DOMContentLoaded', function() {
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            let isValid = true;
            const errors = {};
            
            // Проверка логина
            const login = document.getElementById('login').value.trim();
            if (login.length < 6 || !/^[а-яА-ЯёЁ]+$/.test(login)) {
                errors.login = 'Логин должен содержать только кириллицу и быть не менее 6 символов';
                isValid = false;
            }
            
            // Проверка ФИО
            const fio = document.getElementById('fio').value.trim();
            if (!/^[а-яА-ЯёЁ\s]+$/.test(fio)) {
                errors.fio = 'ФИО должно содержать только кириллицу и пробелы';
                isValid = false;
            }
            
            // Проверка телефона
            const phone = document.getElementById('phone').value.trim();
            if (!/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/.test(phone)) {
                errors.phone = 'Телефон должен быть в формате +7(XXX)-XXX-XX-XX';
                isValid = false;
            }
            
            // Проверка email
            const email = document.getElementById('email').value.trim();
            if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                errors.email = 'Введите корректный email';
                isValid = false;
            }
            
            // Проверка пароля
            const password = document.getElementById('password').value;
            if (password.length < 6) {
                errors.password = 'Пароль должен быть не менее 6 символов';
                isValid = false;
            }
            
            // Проверка подтверждения пароля
            const passwordConfirm = document.getElementById('password_confirm').value;
            if (password !== passwordConfirm) {
                errors.password_confirm = 'Пароли не совпадают';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
                
                // Показываем ошибки
                document.querySelectorAll('.error-message').forEach(el => el.remove());
                
                for (const field in errors) {
                    const input = document.getElementById(field);
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'error-message';
                    errorDiv.style.color = 'var(--error-color)';
                    errorDiv.style.fontSize = '0.8rem';
                    errorDiv.style.marginTop = '5px';
                    errorDiv.textContent = errors[field];
                    
                    input.parentNode.appendChild(errorDiv);
                }
            }
        });
    }
    
    // Валидация формы заявки
    const applicationForm = document.getElementById('application-form');
    if (applicationForm) {
        applicationForm.addEventListener('submit', function(e) {
            let isValid = true;
            const errors = {};
            
            // Проверка курса
            const courseId = document.getElementById('course_id').value;
            if (!courseId) {
                errors.course_id = 'Выберите курс';
                isValid = false;
            }
            
            // Проверка даты
            const date = document.getElementById('desired_start_date').value.trim();
            if (!/^\d{2}\.\d{2}\.\d{4}$/.test(date)) {
                errors.desired_start_date = 'Дата должна быть в формате ДД.ММ.ГГГГ';
                isValid = false;
            } else {
                const parts = date.split('.');
                const day = parseInt(parts[0], 10);
                const month = parseInt(parts[1], 10);
                const year = parseInt(parts[2], 10);
                
                const dateObj = new Date(year, month - 1, day);
                if (dateObj.getFullYear() !== year || 
                    dateObj.getMonth() + 1 !== month || 
                    dateObj.getDate() !== day) {
                    errors.desired_start_date = 'Некорректная дата';
                    isValid = false;
                } else if (dateObj < new Date()) {
                    errors.desired_start_date = 'Дата не может быть в прошлом';
                    isValid = false;
                }
            }
            
            // Проверка способа оплаты
            const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
            if (!paymentMethod) {
                errors.payment_method = 'Выберите способ оплаты';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
                
                // Показываем ошибки
                document.querySelectorAll('.error-message').forEach(el => el.remove());
                
                for (const field in errors) {
                    let input;
                    if (field === 'payment_method') {
                        input = document.querySelector('.radio-group');
                    } else {
                        input = document.getElementById(field);
                    }
                    
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'error-message';
                    errorDiv.style.color = 'var(--error-color)';
                    errorDiv.style.fontSize = '0.8rem';
                    errorDiv.style.marginTop = '5px';
                    errorDiv.textContent = errors[field];
                    
                    if (input.parentNode) {
                        input.parentNode.appendChild(errorDiv);
                    }
                }
            }
        });
    }
});