<?php
require_once 'includes/auth_check.php';
requireAuth();

$title = 'Личный кабинет';
$additional_scripts = ['main.js'];
require_once 'includes/header.php';

require_once 'database/db_connection.php';

// Получаем заявки пользователя
$stmt = $pdo->prepare("
    SELECT a.*, c.name as course_name 
    FROM applications a
    JOIN courses c ON a.course_id = c.id
    WHERE a.user_id = ?
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetchAll();
?>

<section class="dashboard">
    <h1>Добро пожаловать, <?php echo htmlspecialchars($_SESSION['login']); ?>!</h1>
    
    <div class="actions">
        <a href="/create_application.php" class="btn">Подать новую заявку</a>
    </div>
    
    <h2>Ваши заявки</h2>
    
    <?php if (empty($applications)): ?>
        <p>У вас пока нет заявок на обучение.</p>
    <?php else: ?>
        <div class="applications-list">
            <?php foreach ($applications as $app): ?>
                <div class="application-card">
                    <h3><?php echo htmlspecialchars($app['course_name']); ?></h3>
                    <p>Желаемая дата начала: <?php echo date('d.m.Y', strtotime($app['desired_start_date'])); ?></p>
                    <p>Способ оплаты: <?php echo $app['payment_method'] === 'cash' ? 'Наличные' : 'Банковский перевод'; ?></p>
                    <p>Статус: 
                        <span class="status-<?php echo $app['status']; ?>">
                            <?php 
                                switch($app['status']) {
                                    case 'new': echo 'Новая'; break;
                                    case 'in_progress': echo 'Идет обучение'; break;
                                    case 'completed': echo 'Обучение завершено'; break;
                                }
                            ?>
                        </span>
                    </p>
                    
                    <?php if ($app['status'] === 'completed' && empty($app['feedback'])): ?>
                        <button class="btn btn-small open-feedback" data-app-id="<?php echo $app['id']; ?>">
                            Оставить отзыв
                        </button>
                        
                        <div class="feedback-form" id="feedback-form-<?php echo $app['id']; ?>" style="display: none;">
                            <textarea class="feedback-text" placeholder="Ваш отзыв о курсе"></textarea>
                            <button class="btn btn-small submit-feedback" data-app-id="<?php echo $app['id']; ?>">
                                Отправить
                            </button>
                        </div>
                    <?php elseif (!empty($app['feedback'])): ?>
                        <div class="feedback">
                            <strong>Ваш отзыв:</strong>
                            <p><?php echo htmlspecialchars($app['feedback']); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</section>

<?php require_once 'includes/footer.php'; ?>