// Анимация загрузки страницы
document.addEventListener('DOMContentLoaded', () => {
    const elements = document.querySelectorAll('.fade-in');
    elements.forEach((el, index) => {
        el.style.animationDelay = `${index * 0.1}s`;
    });
});

// Валидация формы регистрации
function validateRegistration(form) {
    // Проверка логина (кириллица, min 6 символов)
    const loginRegex = /^[а-яёА-ЯЁ]{6,}$/;
    if (!loginRegex.test(form.login.value)) {
        showError('Логин должен содержать только кириллицу и быть не менее 6 символов');
        return false;
    }
    
    // Другие проверки...
    return true;
}

// AJAX для обновления статуса заявки
function updateStatus(appId, status) {
    fetch('/api/update_status', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ appId, status }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showToast('Статус успешно обновлен');
        } else {
            showError('Ошибка при обновлении статуса');
        }
    });
}

// Всплывающие уведомления
function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }, 100);
}