<?php
// Проверка авторизации
// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Создание заявки в БД
}
?>
<form method="POST">
    <select name="course_id" required>
        <option value="">Выберите курс</option>
        <?php foreach ($courses as $course): ?>
        <option value="<?= $course['id'] ?>"><?= $course['name'] ?></option>
        <?php endforeach; ?>
    </select>
    <input type="date" name="start_date" required>
    <select name="payment_method" required>
        <option value="наличными">Наличными</option>
        <option value="перевод">Банковский перевод</option>
    </select>
    <button type="submit">Отправить заявку</button>
</form>