<?php
// Обработка авторизации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Проверка логина/пароля
    // Установка сессии
}
?>
<form method="POST">
    <input type="text" name="login" placeholder="Логин" required>
    <input type="password" name="password" placeholder="Пароль" required>
    <button type="submit">Войти</button>
</form>