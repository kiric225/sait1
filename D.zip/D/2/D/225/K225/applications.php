<?php
// Проверка авторизации
// Получение заявок пользователя из БД
?>
<h2>Мои заявки</h2>
<table>
    <tr>
        <th>Курс</th>
        <th>Дата начала</th>
        <th>Способ оплаты</th>
        <th>Статус</th>
        <th>Действия</th>
    </tr>
    <?php foreach ($applications as $app): ?>
    <tr>
        <td><?= $app['course_name'] ?></td>
        <td><?= $app['start_date'] ?></td>
        <td><?= $app['payment_method'] ?></td>
        <td><?= $app['status'] ?></td>
        <td>
            <?php if ($app['status'] === 'Обучение завершено'): ?>
            <button onclick="showReviewForm(<?= $app['id'] ?>)">Оставить отзыв</button>
            <?php endif; ?>
        </td>
    </tr>
    <?php endforeach; ?>
</table>