<?php require 'db.php';
$errors = [];
if (isset($_POST['login'])) {
    // Валидация
    if (strlen($_POST['login']) < 6 || !preg_match('/^[а-яё]+$/iu', $_POST['login'])) 
        $errors[] = "Логин должен быть не менее 6 символов кириллицы";
    
    if (strlen($_POST['password']) < 6) 
        $errors[] = "Пароль должен быть не менее 6 символов";
    
    if (!preg_match('/^[а-яё\s]+$/iu', $_POST['FIO'])) 
        $errors[] = "ФИО должно содержать только кириллицу и пробелы";
    
    if (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $_POST['phone'])) 
        $errors[] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX";
    
    if (!filter_var($_POST['mail'], FILTER_VALIDATE_EMAIL)) 
        $errors[] = "Некорректный email";
    
    // Проверка уникальности логина
    $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
    $stmt->execute([$_POST['login']]);
    if ($stmt->fetch()) $errors[] = "Логин уже занят";

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO users (login, FIO, phone, mail, password) VALUES (?,?,?,?,?)");
        $stmt->execute([$_POST['login'], $_POST['FIO'], $_POST['phone'], $_POST['mail'], $_POST['password']]);
        header('Location: index.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Регистрация</title>
</head>
<body>
    <div class="container">
        <h1>Регистрация</h1>
        <?php if(!empty($errors)): ?>
            <div class="error"><?=implode('<br>', $errors)?></div>
        <?php endif; ?>
        <form method="POST" onsubmit="return validateForm()">
            <input type="text" name="login" placeholder="Логин (кириллица)" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <input type="text" name="FIO" placeholder="ФИО" required>
            <input type="text" name="phone" placeholder="Телефон +7(XXX)-XXX-XX-XX" required>
            <input type="email" name="mail" placeholder="Email" required>
            <button type="submit">Зарегистрироваться</button>
        </form>
        <a href="index.php">Войти</a>
    </div>
    <script src="script.js"></script>
</body>
</html>