<?php require 'db.php'; 
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

if (isset($_POST['course'])) {
    // Получаем ID курса по имени
    $stmt = $pdo->prepare("SELECT id FROM courses WHERE name = ?");
    $stmt->execute([$_POST['course']]);
    $course = $stmt->fetch();
    
    if ($course) {
        $stmt = $pdo->prepare("INSERT INTO requests (login, course_id, start_date, payment_method, description) 
                              VALUES (?, ?, ?, ?, ?)");
        $description = "Курс: ".$_POST['course'].", Дата: ".$_POST['date'].", Оплата: ".$_POST['payment'];
        $stmt->execute([
            $_SESSION['user']['login'],
            $course['id'],
            $_POST['date'],
            $_POST['payment'],
            $description
        ]);
        header('Location: dashboard.php');
        exit;
    } else {
        $error = "Выбранный курс не найден";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Новая заявка</title>
</head>
<body>
    <div class="container">
        <h1>Новая заявка</h1>
        <?php if(isset($error)): ?>
            <div class="error"><?=$error?></div>
        <?php endif; ?>
        <form method="POST">
            <select name="course" required>
                <option value="">Выберите курс</option>
                <?php
                $courses = $pdo->query("SELECT * FROM courses")->fetchAll();
                foreach($courses as $course): ?>
                    <option value="<?=htmlspecialchars($course['name'])?>">
                        <?=htmlspecialchars($course['name'])?>
                    </option>
                <?php endforeach; ?>
            </select>
            <input type="date" name="date" required>
            <div class="radio-group">
                <label><input type="radio" name="payment" value="Наличные" checked> Наличные</label>
                <label><input type="radio" name="payment" value="Банковский перевод"> Банковский перевод</label>
            </div>
            <button type="submit">Отправить заявку</button>
        </form>
        <a href="dashboard.php">Назад</a>
    </div>
</body>
</html>