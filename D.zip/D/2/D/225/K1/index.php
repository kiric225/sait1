<?php require 'db.php'; 
if (isset($_POST['login'])) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$_POST['login']]);
    $user = $stmt->fetch();
    
    if ($user && $user['password'] === $_POST['password']) {
        $_SESSION['user'] = $user;
        header('Location: '.($user['isAdmin']=='Администратор'?'admin.php':'dashboard.php'));
        exit;
    } else {
        $error = "Неверный логин или пароль";
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Авторизация</title>
</head>
<body>
    <div class="container">
        <h1>Вход в систему</h1>
        <?php if(isset($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="login" placeholder="Логин" required>
            <input type="password" name="password" placeholder="Пароль" required>
            <button type="submit">Войти</button>
        </form>
        <a href="register.php">Регистрация</a>
    </div>
</body>
</html>