<?php 
require 'db.php'; 

// Проверка авторизации
if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

// Получение заявок пользователя
$stmt = $pdo->prepare("SELECT r.*, c.name as course_name 
                      FROM requests r 
                      JOIN courses c ON r.course_id = c.id 
                      WHERE r.login = ? 
                      ORDER BY r.id DESC");
$stmt->execute([$_SESSION['user']['login']]);
$requests = $stmt->fetchAll();

// Добавление отзыва
if (isset($_POST['feedback']) && isset($_POST['id'])) {
    $stmt = $pdo->prepare("UPDATE requests SET feedback = ? WHERE id = ? AND login = ?");
    $stmt->execute([
        $_POST['feedback'], 
        $_POST['id'], 
        $_SESSION['user']['login']
    ]);
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Мои заявки</title>
</head>
<body>
    <div class="container">
        <h1>Мои заявки</h1>
        <a href="create_request.php" class="button">Новая заявка</a>
        <div class="requests">
            <?php foreach($requests as $req): ?>
            <div class="request">
                <h3><?=htmlspecialchars($req['course_name'])?></h3>
                <p>Дата начала: <?=htmlspecialchars($req['start_date'])?></p>
                <p>Способ оплаты: <?=htmlspecialchars($req['payment_method'])?></p>
                <p>Статус: <?=$req['status']?></p>
                <?php if($req['status'] == 'Обучение завершено' && empty($req['feedback'])): ?>
                    <form method="POST">
                        <input type="hidden" name="id" value="<?=$req['id']?>">
                        <textarea name="feedback" placeholder="Ваш отзыв" required></textarea>
                        <button type="submit">Отправить отзыв</button>
                    </form>
                <?php elseif(!empty($req['feedback'])): ?>
                    <p><strong>Ваш отзыв:</strong> <?=htmlspecialchars($req['feedback'])?></p>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <a href="index.php?logout" class="logout">Выйти</a>
    </div>
</body>
</html>