// Валидация телефона
document.addEventListener('DOMContentLoaded', function() {
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            e.target.value = !x[2] ? x[1] : '+7(' + x[2] + (x[3] ? ')-' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
        });
    }
});

// Валидация формы регистрации
function validateForm() {
    const login = document.querySelector('input[name="login"]');
    if (login && !/^[а-яё]{6,}$/iu.test(login.value)) {
        alert('Логин должен быть не менее 6 символов кириллицы');
        return false;
    }
    return true;
}