<?php
if (!isset($_SESSION['user'])) {
    header('Location: ?page=login');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedback'])) {
    $stmt = $pdo->prepare("UPDATE applications SET feedback = ? WHERE id = ? AND user_id = ? AND status = 'completed'");
    $stmt->execute([$_POST['feedback'], $_POST['app_id'], $_SESSION['user']['id']]);
}

$stmt = $pdo->prepare("
    SELECT a.*, c.name as course_name 
    FROM applications a 
    JOIN courses c ON a.course_id = c.id 
    WHERE a.user_id = ?
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user']['id']]);
$applications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заявки</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .app { border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 5px; }
        .new { background-color: #f0f8ff; }
        .in_progress { background-color: #fffaf0; }
        .completed { background-color: #f0fff0; }
        button { padding: 5px 10px; margin-top: 10px; }
    </style>
</head>
<body>
    <h1>Мои заявки</h1>
    <a href="?page=new_application">Создать новую заявку</a>
    <a href="?page=logout" style="float:right">Выйти</a>
    
    <?php foreach ($applications as $app): ?>
        <div class="app <?= $app['status'] ?>">
            <h3><?= $app['course_name'] ?></h3>
            <p>Дата начала: <?= $app['start_date'] ?></p>
            <p>Способ оплаты: <?= $app['payment_method'] === 'cash' ? 'Наличные' : 'Банковский перевод' ?></p>
            <p>Статус: <?= 
                $app['status'] === 'new' ? 'Новая' : 
                ($app['status'] === 'in_progress' ? 'Идет обучение' : 'Обучение завершено') 
            ?></p>
            
            <?php if ($app['status'] === 'completed'): ?>
                <form method="post">
                    <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                    <textarea name="feedback" placeholder="Ваш отзыв" rows="3" style="width:100%"><?= $app['feedback'] ?? '' ?></textarea>
                    <button type="submit">Сохранить отзыв</button>
                </form>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</body>
</html>