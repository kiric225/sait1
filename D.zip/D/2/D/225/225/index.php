<?php
session_start();
require 'db.php';

// Основные функции
function isAdmin() {
    return isset($_SESSION['user']) && $_SESSION['user']['login'] === 'admin';
}

function validatePhone($phone) {
    return preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone);
}

function validateDate($date) {
    return preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $date);
}

// Маршрутизация
$page = $_GET['page'] ?? 'login';

switch ($page) {
    case 'register': include 'register.php'; break;
    case 'applications': include 'applications.php'; break;
    case 'new_application': include 'new_application.php'; break;
    case 'admin': include 'admin.php'; break;
    case 'logout': session_destroy(); header('Location: ?page=login'); break;
    default: include 'login.php';
}
?>