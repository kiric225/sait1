<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);

    if (strlen($login) < 6 || !preg_match('/^[а-яё\s]+$/iu', $login)) {
        $errors[] = 'Логин должен быть не менее 6 символов кириллицы';
    }

    if (strlen($password) < 6) {
        $errors[] = 'Пароль должен быть не менее 6 символов';
    }

    if (!preg_match('/^[а-яё\s]+$/iu', $full_name)) {
        $errors[] = 'ФИО должно содержать только кириллицу и пробелы';
    }

    if (!validatePhone($phone)) {
        $errors[] = 'Телефон должен быть в формате +7(XXX)-XXX-XX-XX';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Некорректный email';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
        $stmt->execute([$login]);
        if ($stmt->fetch()) {
            $errors[] = 'Логин уже занят';
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (login, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$login, password_hash($password, PASSWORD_DEFAULT), $full_name, $phone, $email]);
            $_SESSION['user'] = $pdo->lastInsertId();
            header('Location: ?page=applications');
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 10px; }
        input, button { width: 100%; padding: 8px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h1>Регистрация</h1>
    <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $error): ?>
            <div class="error"><?= $error ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
    <form method="post">
        <input type="text" name="login" placeholder="Логин" required>
        <input type="password" name="password" placeholder="Пароль" required>
        <input type="text" name="full_name" placeholder="ФИО" required>
        <input type="tel" name="phone" placeholder="Телефон (+7(XXX)-XXX-XX-XX)" required>
        <input type="email" name="email" placeholder="Email" required>
        <button type="submit">Зарегистрироваться</button>
    </form>
    <p>Уже есть аккаунт? <a href="?page=login">Войти</a></p>
</body>
</html>