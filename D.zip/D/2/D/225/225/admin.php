<?php
if (!isAdmin()) {
    header('Location: ?page=login');
    exit;
}

$status = $_GET['status'] ?? 'all';
$where = '';
if (in_array($status, ['new', 'in_progress', 'completed'])) {
    $where = "WHERE a.status = '$status'";
}

$stmt = $pdo->prepare("
    SELECT a.*, u.full_name, u.email, u.phone, c.name as course_name 
    FROM applications a 
    JOIN users u ON a.user_id = u.id 
    JOIN courses c ON a.course_id = c.id 
    $where
    ORDER BY a.created_at DESC
");
$stmt->execute();
$applications = $stmt->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['app_id']]);
    header("Location: ?page=admin&status=$status");
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 1000px; margin: 0 auto; padding: 20px; }
        .app { border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 5px; }
        .new { background-color: #f0f8ff; }
        .in_progress { background-color: #fffaf0; }
        .completed { background-color: #f0fff0; }
        .filters { margin-bottom: 20px; }
        .filters a { margin-right: 10px; padding: 5px; }
        .active { font-weight: bold; text-decoration: none; color: #000; }
    </style>
</head>
<body>
    <h1>Панель администратора</h1>
    <div class="filters">
        <span>Фильтр: </span>
        <a href="?page=admin" class="<?= $status === 'all' ? 'active' : '' ?>">Все</a>
        <a href="?page=admin&status=new" class="<?= $status === 'new' ? 'active' : '' ?>">Новые</a>
        <a href="?page=admin&status=in_progress" class="<?= $status === 'in_progress' ? 'active' : '' ?>">В процессе</a>
        <a href="?page=admin&status=completed" class="<?= $status === 'completed' ? 'active' : '' ?>">Завершенные</a>
        <a href="?page=logout" style="float:right">Выйти</a>
    </div>
    
    <?php foreach ($applications as $app): ?>
        <div class="app <?= $app['status'] ?>">
            <h3><?= $app['course_name'] ?> (<?= $app['full_name'] ?>)</h3>
            <p>Контактные данные: <?= $app['email'] ?>, <?= $app['phone'] ?></p>
            <p>Дата начала: <?= $app['start_date'] ?></p>
            <p>Способ оплаты: <?= $app['payment_method'] === 'cash' ? 'Наличные' : 'Банковский перевод' ?></p>
            <p>Статус: <?= 
                $app['status'] === 'new' ? 'Новая' : 
                ($app['status'] === 'in_progress' ? 'Идет обучение' : 'Обучение завершено') 
            ?></p>
            
            <?php if ($app['feedback']): ?>
                <p><strong>Отзыв:</strong> <?= $app['feedback'] ?></p>
            <?php endif; ?>
            
            <form method="post">
                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                <select name="status">
                    <option value="new" <?= $app['status'] === 'new' ? 'selected' : '' ?>>Новая</option>
                    <option value="in_progress" <?= $app['status'] === 'in_progress' ? 'selected' : '' ?>>Идет обучение</option>
                    <option value="completed" <?= $app['status'] === 'completed' ? 'selected' : '' ?>>Обучение завершено</option>
                </select>
                <button type="submit">Обновить статус</button>
            </form>
        </div>
    <?php endforeach; ?>
</body>
</html>