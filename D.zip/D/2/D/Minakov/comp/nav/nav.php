<?php
if (isset($_COOKIE['login'])) {
    if (isset($_COOKIE['isAdmin']) && $_COOKIE['isAdmin'] == 1) {
        echo '
        <nav>
            <a href="#">Главная</a>
            <a href="../../../logout.php">Выход</a>
        </nav>';
    } else {
        echo '
        <nav>
            <a href="#">Главная</a>
            <a href="#">Личный кабинет</a>
            <a href="../../../logout.php">Выход</a>
        </nav>';
    }
} else {
    echo '
    <nav>
        <a href="./page_reg.php">Регистрация</a>
        <a href="./page_auth.php">Авторизация</a>
    </nav>';
}