<?php

if (isset($_GET['yavka_true'])) {
    $dbh = $conn->prepare("UPDATE yavka SET status = 1 WHERE id = :id");
    $dbh->execute(['id' => htmlentities($_GET['yavka_true'])]);
}

if (isset($_GET['yavka_false'])) {
    $dbh = $conn->prepare("UPDATE yavka SET status = 2 WHERE id = :id");
    $dbh->execute(['id' => htmlentities($_GET['yavka_false'])]);
}