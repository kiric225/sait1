<?php
include '../../conn/conn.php';
include '../../zayavka_user/create_zayavka.php';
include '../../../comp/forms/forma_zayavka.php';


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Личный кабинет</title>
    <link rel="stylesheet" href="../../../styles/styles.css">
</head>
<body>
    <header>
        <h1>Интернет - не роскошь. Личный кабинет</h1>
    </header>

    <nav>
        <?php 
            include '../../../comp/nav/nav.php';
        ?>
    </nav>

    <main>
        <h2 style= 'align: center'>
            Добро пожаловать, 
                            <?php echo ($_COOKIE['login']) . ' !'; ?>
        </h2>
        <?php
        form_yavka();
        if (isset($error_yavka)) {
            echo $error_yavka;
        }
        include '../../zayavka_user/my_zayavka.php';
        ?>
    </main>

    <footer>
        <p>Футер</p>
    </footer>
</body>
</html>
