document.addEventListener('DOMContentLoaded', function() {
    // Динамическое заполнение моделей
    const markaSelect = document.getElementById('marka');
    const modelSelect = document.getElementById('model');
    
    const models = {
        'Toyota': ['Camry', 'Corolla', 'RAV4', 'Land Cruiser'],
        'Honda': ['Accord', 'Civic', 'CR-V', 'Pilot'],
        'BMW': ['3 Series', '5 Series', 'X5', 'X7']
    };
    
    if (markaSelect && modelSelect) {
        markaSelect.addEventListener('change', function() {
            const selectedMarka = this.value;
            modelSelect.innerHTML = '<option value="">Выберите модель</option>';
            
            if (selectedMarka && models[selectedMarka]) {
                models[selectedMarka].forEach(model => {
                    const option = document.createElement('option');
                    option.value = model;
                    option.textContent = model;
                    modelSelect.appendChild(option);
                });
            }
        });
    }

    // Обработка кнопки "Отклонить"
    const rejectButtons = document.querySelectorAll('.reject-btn');
    rejectButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const form = this.closest('.request-actions');
            const rejectForm = form.querySelector('.reject-form');
            rejectForm.style.display = rejectForm.style.display === 'none' ? 'block' : 'none';
        });
    });
});