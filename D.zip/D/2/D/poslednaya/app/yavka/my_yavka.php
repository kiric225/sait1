<?php
// Вывод заявок пользователя
$dbh = $conn->prepare("SELECT * FROM yavka WHERE name = :name");
$dbh->execute(['name' => htmlentities($_COOKIE['login'])]);

if ($dbh->rowCount() > 0) {
    $yavkauser = $dbh->fetchAll(PDO::FETCH_ASSOC);

    echo '<br>';
    echo '<h2 class="flex">Ваши заявки</h2>';
    echo '<div class="flex">';
    echo '<table>';
    echo '<thead>
            <tr>
                <th>ID</th>
                <th>Имя</th>
                <th>Телефон</th>
                <th>Адрес</th>
                <th>Тип услуги</th>
                <th>Тип оплаты</th>
                <th>Время</th>
                <th>Комментарий</th>
                <th>Статус</th>
            </tr>
        </thead>';
    
        foreach ($yavki as $ya => $value) {
            echo '<tr>';
            echo '<td>' . $yavki[$ya]['id'] . '</td>';
            echo '<td>' . $yavki[$ya]['name'] . '</td>';
            echo '<td>' . $yavki[$ya]['phone'] . '</td>';
            echo '<td>' . $yavki[$ya]['address'] . '</td>';
            echo '<td>' . $yavki[$ya]['type_service'] . '</td>';
            echo '<td>' . $yavki[$ya]['type_oplaty'] . '</td>';
            echo '<td>' . $yavki[$ya]['time'] . '</td>';
            echo '<td>' . $yavki[$ya]['comment'] . '</td>';
    
            if ($yavki[$ya]['status'] == 2) {
                echo '<td style="background:rgb(238, 255, 0)">' . 'На рассмотрении' . '</td>';
            } else if ($yavki[$ya]['status'] == 0) {
                echo '<td style="background:rgb(78, 248, 90)">' . 'Одобрено' . '</td>';
            } else if ($yavki[$ya]['status'] == 1) {
                echo '<td style="background:rgb(252, 120, 120)">' . 'Отменено' . '</td>';
            }

        echo '</tr>';
    }

    echo '</table>';
    echo '</div>';
} else {
    echo '<p style="text-align:center;">У вас пока нет заявок.</p>';
}

echo "<link rel='stylesheet' href='../../../styles/table.css'>";
