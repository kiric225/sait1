<?php
require 'includes/functions.php';

if (!isAdmin()) {
    header('Location: index.php');
    exit;
}

global $pdo;

// Получаем все заявки с информацией о пользователях
$stmt = $pdo->query("
    SELECT t.*, u.FIO, u.phone, u.mail 
    FROM tasks t
    JOIN users u ON t.login = u.id
    ORDER BY t.status, t.id DESC
");
$requests = $stmt->fetchAll();

// Обновление статуса
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $requestId = $_POST['request_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
    $stmt->execute([$status, $requestId]);
    header('Location: admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - Корочки.есть</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Панель администратора</h1>
        <a href="logout.php" class="btn logout">Выйти</a>
        
        <h2>Все заявки</h2>
        <div class="requests">
            <?php foreach ($requests as $request): ?>
                <div class="request">
                    <h3><?= htmlspecialchars($request['course_name']) ?></h3>
                    <p>Пользователь: <?= htmlspecialchars($request['FIO']) ?></p>
                    <p>Контакты: <?= htmlspecialchars($request['phone']) ?>, <?= htmlspecialchars($request['mail']) ?></p>
                    <p>Дата начала: <?= date('d.m.Y', strtotime($request['start_date'])) ?></p>
                    <p>Способ оплаты: <?= htmlspecialchars($request['payment_method']) ?></p>
                    <p>Статус: <?= htmlspecialchars($request['status']) ?></p>
                    
                    <?php if ($request['feedback']): ?>
                        <p><strong>Отзыв:</strong> <?= htmlspecialchars($request['feedback']) ?></p>
                    <?php endif; ?>
                    
                    <form method="POST" class="status-form">
                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                        <select name="status">
                            <option value="Новый" <?= $request['status'] === 'Новый' ? 'selected' : '' ?>>Новый</option>
                            <option value="Идет обучение" <?= $request['status'] === 'Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                            <option value="Обучение завершено" <?= $request['status'] === 'Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
                        </select>
                        <button type="submit" class="btn small">Обновить</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>