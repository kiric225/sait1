<?php
require 'includes/functions.php';

if (!isLoggedIn()) {
    header('Location: index.php');
    exit;
}

global $pdo;
$userId = $_SESSION['user']['id'];

// Получаем заявки пользователя
$stmt = $pdo->prepare("SELECT * FROM tasks WHERE login = ? ORDER BY id DESC");
$stmt->execute([$userId]);
$requests = $stmt->fetchAll();

// Обработка отправки отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedback'])) {
    $requestId = $_POST['request_id'];
    $feedback = $_POST['feedback'];
    
    $stmt = $pdo->prepare("UPDATE tasks SET feedback = ? WHERE id = ? AND login = ?");
    $stmt->execute([$feedback, $requestId, $userId]);
    header('Location: dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заявки - Корочки.есть</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Добро пожаловать, <?= htmlspecialchars($_SESSION['user']['FIO']) ?>!</h1>
        <a href="create_request.php" class="btn">Создать новую заявку</a>
        <a href="logout.php" class="btn logout">Выйти</a>
        
        <h2>Мои заявки</h2>
        <?php if (empty($requests)): ?>
            <p>У вас пока нет заявок</p>
        <?php else: ?>
            <div class="requests">
                <?php foreach ($requests as $request): ?>
                    <div class="request">
                        <h3><?= htmlspecialchars($request['course_name']) ?></h3>
                        <p>Дата начала: <?= date('d.m.Y', strtotime($request['start_date'])) ?></p>
                        <p>Способ оплаты: <?= htmlspecialchars($request['payment_method']) ?></p>
                        <p>Статус: <?= htmlspecialchars($request['status']) ?></p>
                        
                        <?php if ($request['status'] === 'Обучение завершено'): ?>
                            <form method="POST">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <div class="form-group">
                                    <label for="feedback-<?= $request['id'] ?>">Отзыв:</label>
                                    <textarea id="feedback-<?= $request['id'] ?>" name="feedback"><?= 
                                        htmlspecialchars($request['feedback'] ?? '') ?></textarea>
                                </div>
                                <button type="submit" class="btn">Сохранить отзыв</button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>