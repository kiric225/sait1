<?php
require 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $password = $_POST['password'] ?? '';
    $fio = $_POST['fio'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $mail = $_POST['mail'] ?? '';
    
    $errors = [];
    
    if (!validateLogin($login)) {
        $errors[] = "Логин должен содержать только кириллицу и быть не менее 6 символов";
    }
    
    if (strlen($password) < 6) {
        $errors[] = "Пароль должен быть не менее 6 символов";
    }
    
    if (!preg_match('/^[а-яА-ЯёЁ\s]+$/u', $fio)) {
        $errors[] = "ФИО должно содержать только кириллицу и пробелы";
    }
    
    if (!validatePhone($phone)) {
        $errors[] = "Телефон должен быть в формате +7(XXX)-XXX-XX-XX";
    }
    
    if (!validateEmail($mail)) {
        $errors[] = "Некорректный email";
    }
    
    if (empty($errors)) {
        global $pdo;
        $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
        $stmt->execute([$login]);
        
        if ($stmt->fetch()) {
            $errors[] = "Пользователь с таким логином уже существует";
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (login, password, FIO, phone, mail) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$login, $password, $fio, $phone, $mail])) {
                header('Location: index.php?registered=1');
                exit;
            } else {
                $errors[] = "Ошибка при регистрации";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Корочки.есть</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Регистрация</h1>
        <?php if (!empty($errors)): ?>
            <div class="alert error">
                <?php foreach ($errors as $error): ?>
                    <p><?= $error ?></p>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <form method="POST" id="registerForm">
            <div class="form-group">
                <label for="login">Логин (кириллица, ≥6 символов):</label>
                <input type="text" id="login" name="login" required pattern="[а-яА-Я]{6,}">
            </div>
            <div class="form-group">
                <label for="password">Пароль (≥6 символов):</label>
                <input type="password" id="password" name="password" required minlength="6">
            </div>
            <div class="form-group">
                <label for="fio">ФИО:</label>
                <input type="text" id="fio" name="fio" required pattern="[а-яА-ЯёЁ\s]+">
            </div>
            <div class="form-group">
                <label for="phone">Телефон:</label>
                <input type="tel" id="phone" name="phone" required placeholder="+7(XXX)-XXX-XX-XX">
            </div>
            <div class="form-group">
                <label for="mail">Email:</label>
                <input type="email" id="mail" name="mail" required>
            </div>
            <button type="submit" class="btn">Зарегистрироваться</button>
        </form>
        <p>Уже есть аккаунт? <a href="index.php">Войдите</a></p>
    </div>
    
    <script src="js/script.js"></script>
</body>
</html>