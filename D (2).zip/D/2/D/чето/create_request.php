<?php
include 'connect.php';

if (!isset($_COOKIE['user_id']) || ($_COOKIE['is_admin'] ?? false)) {
    header('Location: auth.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_COOKIE['user_id'];
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    $date = $_POST['date'];
    $marka = $_POST['marka'];
    $model = $_POST['model'];
    $license_number = trim($_POST['license_number']);
    $license_date = $_POST['license_date'];
    $payment_type = $_POST['payment_type'];
    
    try {
        $stmt = $conn->prepare("INSERT INTO requests 
            (user_id, address, phone, date, marka, model, license_number, license_date, payment_type) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        
        $stmt->execute([
            $user_id, $address, $phone, $date, 
            $marka, $model, $license_number, 
            $license_date, $payment_type
        ]);
        
        header('Location: index.php?success=1');
        exit();
    } catch (PDOException $e) {
        header('Location: index.php?error=' . urlencode($e->getMessage()));
        exit();
    }
} else {
    header('Location: index.php');
    exit();
}
?>