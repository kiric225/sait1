<?php
include 'connect.php';

if (!isset($_COOKIE['user_id'])) {
    header('Location: auth.php');
    exit();
}

$is_admin = $_COOKIE['is_admin'] ?? false;

// Получение заявок
if ($is_admin) {
    $stmt = $conn->query("SELECT r.*, u.fio FROM requests r JOIN users u ON r.user_id = u.id ORDER BY r.created_at DESC");
} else {
    $stmt = $conn->prepare("SELECT * FROM requests WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$_COOKIE['user_id']]);
}
$requests = $stmt->fetchAll();

// Обработка действий администратора
if ($is_admin && isset($_POST['action'])) {
    $request_id = $_POST['request_id'];
    $status = '';
    $reason = '';
    
    switch ($_POST['action']) {
        case 'approve':
            $status = 'approved';
            break;
        case 'reject':
            $status = 'rejected';
            $reason = $_POST['reason'] ?? '';
            break;
        case 'complete':
            $status = 'completed';
            break;
    }
    
    $stmt = $conn->prepare("UPDATE requests SET status = ?, rejection_reason = ? WHERE id = ?");
    $stmt->execute([$status, $reason, $request_id]);
    
    header("Location: index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $is_admin ? 'Панель администратора' : 'Мои заявки' ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <h1><?= $is_admin ? 'Панель администратора' : 'Мои заявки' ?></h1>
        <a href="logout.php" class="logout">Выйти</a>
    </header>
    
    <main class="container">
        <?php if (!$is_admin): ?>
            <section class="new-request">
                <h2>Новая заявка</h2>
                <form method="post" action="create_request.php">
                    <div class="form-group">
                        <label for="address">Адрес</label>
                        <input type="text" id="address" name="address" required>
                    </div>
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="tel" id="phone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label for="date">Дата и время тест-драйва</label>
                        <input type="datetime-local" id="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label for="license_number">Номер водительского удостоверения</label>
                        <input type="text" id="license_number" name="license_number" required>
                    </div>
                    <div class="form-group">
                        <label for="license_date">Дата выдачи удостоверения</label>
                        <input type="date" id="license_date" name="license_date" required>
                    </div>
                    <div class="form-group">
                        <label for="payment_type">Тип оплаты</label>
                        <select id="payment_type" name="payment_type" required>
                            <option value="cash">Наличные</option>
                            <option value="card">Банковская карта</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="marka">Марка автомобиля</label>
                        <select id="marka" name="marka" required>
                            <option value="">Выберите марку</option>
                            <option value="Toyota">Toyota</option>
                            <option value="Honda">Honda</option>
                            <option value="BMW">BMW</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="model">Модель автомобиля</label>
                        <select id="model" name="model" required>
                            <option value="">Сначала выберите марку</option>
                        </select>
                    </div>
                    <button type="submit">Создать заявку</button>
                </form>
            </section>
        <?php endif; ?>
        
        <section class="requests">
            <h2><?= $is_admin ? 'Все заявки' : 'История заявок' ?></h2>
            
            <?php if (empty($requests)): ?>
                <p>Нет заявок</p>
            <?php else: ?>
                <div class="request-list">
                    <?php foreach ($requests as $request): ?>
                        <div class="request-card status-<?= $request['status'] ?>">
                            <div class="request-header">
                                <h3>Заявка #<?= $request['id'] ?></h3>
                                <span class="status"><?= [
                                    'pending' => 'Ожидание',
                                    'approved' => 'Одобрено',
                                    'rejected' => 'Отклонено',
                                    'completed' => 'Выполнено'
                                ][$request['status']] ?></span>
                            </div>
                            
                            <div class="request-body">
                                <p><strong>Марка:</strong> <?= $request['marka'] ?></p>
                                <p><strong>Модель:</strong> <?= $request['model'] ?></p>
                                <p><strong>Дата:</strong> <?= date('d.m.Y H:i', strtotime($request['date'])) ?></p>
                                <p><strong>Адрес:</strong> <?= $request['address'] ?></p>
                                <p><strong>Телефон:</strong> <?= $request['phone'] ?></p>
                                <p><strong>Оплата:</strong> <?= $request['payment_type'] === 'cash' ? 'Наличные' : 'Карта' ?></p>
                                
                                <?php if ($is_admin): ?>
                                    <p><strong>Клиент:</strong> <?= $request['fio'] ?></p>
                                <?php endif; ?>
                                
                                <?php if ($request['status'] === 'rejected' && $request['rejection_reason']): ?>
                                    <p class="reason"><strong>Причина отказа:</strong> <?= $request['rejection_reason'] ?></p>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($is_admin && $request['status'] === 'pending'): ?>
                                <div class="request-actions">
                                    <form method="post">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <button type="submit" name="action" value="approve">Одобрить</button>
                                        <button type="button" class="reject-btn">Отклонить</button>
                                        <div class="reject-form" style="display: none;">
                                            <textarea name="reason" placeholder="Причина отказа" required></textarea>
                                            <button type="submit" name="action" value="reject">Подтвердить</button>
                                        </div>
                                    </form>
                                </div>
                            <?php elseif ($is_admin && $request['status'] === 'approved'): ?>
                                <div class="request-actions">
                                    <form method="post">
                                        <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                        <button type="submit" name="action" value="complete">Завершить</button>
                                    </form>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>
    
    <script src="script.js"></script>
</body>
</html>