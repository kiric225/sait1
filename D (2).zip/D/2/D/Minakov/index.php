<?php
require_once './app/conn/conn.php';

if (!isset($_COOKIE['login'])) {
    header("Location: ./page_auth.php");
}

if (isset($_COOKIE['login'])) {
    if ($_COOKIE['isAdmin'] == 1) {
        header("Location: ./app/index/admin/admin_page.php");
    } else {
        header("Location: ./app/index/user/user_page.php");
    }
}