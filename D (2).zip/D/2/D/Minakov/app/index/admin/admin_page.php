<?php
require_once '../../conn/conn.php';

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ</title>
    <link rel="stylesheet" href="../../../styles/styles.css">
</head>
<body>
    <header>
        <h1>Интернет - не роскошь. Личный кабинет.</h1>
    </header>

    <nav>
        <?php 
            require_once '../../../comp/nav/nav.php'; 
        ?>
    </nav>

    <main>
        <h2 style= 'align: center'>
            Приветствую, 
                            <?php echo ($_COOKIE['login']) . '!'; ?>
        </h2>
        <p>Моя админка</p>
        <?php
            include '../../zayavka_admin/zayavka_table.php';
        ?>
    </main>

    <footer>
        <p>Футер</p>
    </footer>
</body>
</html>
