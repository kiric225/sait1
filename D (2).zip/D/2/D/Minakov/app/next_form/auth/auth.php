<?php
if (isset($_POST['login']) && isset($_POST['password'])) {

    $dbh = $conn->prepare
    ("SELECT * FROM users WHERE login = :login and password = :password");

    $dbh->execute([  
        'login'     =>htmlentities($_POST['login']), 
        "password"  =>htmlentities($_POST['password'])
    ]);

    if ($dbh->rowCount() > 0) {
        $m = $dbh->fetch(PDO::FETCH_ASSOC);
        
        setcookie("login",   $m["login"]);
        setcookie("isAdmin", $m["isAdmin"]);
        setcookie("id",      $m["id"]);

        header("Location: ../../../index.php");
    } else {
        $error_auth = "<p style='color: red;'>Неправильный логин или пароль!</p>";
    }
} else {
    $error_auth = '';
}