<?php

setcookie('login', '');
setcookie('isAdmin', '');
setcookie('tel', '');

header('Location: ./auth.php');