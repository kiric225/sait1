<?php
$error = null;
if (isset($_POST['login'])) {

    $dbh = $conn->prepare('SELECT * FROM users where login = :login');
    $dbh->execute(['login' => $_POST['login']]);

    if ($dbh->rowCount() > 0) {
        $error = 'Такой пользователь уже есть';
    } else {
        
        $dbh = $conn->prepare('INSERT INTO `users` (`login`, `password`, `phone`, `mail`, `fio`) VALUES (:login, :password, :phone, :mail, :fio)');
        $dbh->execute(['login' => $_POST['login'], 'password' => $_POST['password'], 'phone' => $_POST['phone'], 'mail' => $_POST['mail'], 'fio' => $_POST['fio']]);
        
        setcookie('login', $_POST['login']);
        setcookie('tel', $_POST['phone']);
        setcookie('isAdmin', 0);

        header('Location: ./index.php');

    }

}