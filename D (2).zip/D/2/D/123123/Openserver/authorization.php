<?php
$error = null;
if (isset($_POST['login']) && isset($_POST['password'])) {

    $dbh = $conn->prepare('SELECT * FROM users where login = :login and password = :password');
    $dbh->execute(['login' => $_POST['login'], 'password' => $_POST['password']]);

    if ($dbh->rowCount() > 0) {
        $user = $dbh->fetch(PDO::FETCH_ASSOC);
        setcookie('login', $user['login']);
        setcookie('tel', $user['phone']);
        setcookie('isAdmin', $user['isAdmin']);
        header('Location: ./index.php');
        // print_r($user);
    } else {
        $error = 'Такого логина и пароля нет';
    }

}