<?php

$error = null;

if (isset($_GET['acc'])) {
    $dbh = $conn->prepare('UPDATE `requests` SET `status` = :status WHERE id = :id');
    $dbh->execute(['id' => $_GET['acc'],'status' => 'Принято']);
}
if (isset($_GET['noacc'])) {
    $dbh = $conn->prepare('UPDATE `requests` SET `status` = :status WHERE id = :id');
    $dbh->execute(['id' => $_GET['noacc'],'status' => 'Отклонено']);
}




if ($_COOKIE['isAdmin'] == 0) {
    $dbh = $conn->prepare('SELECT * FROM requests where user = :user');
    $dbh->execute(['user' => $_COOKIE['login']]);
} else {
    $dbh = $conn->prepare('SELECT * FROM requests');
    $dbh->execute([]);
}


$req = $dbh->fetchAll(PDO::FETCH_ASSOC);

if ($dbh->rowCount() > 0) {
    
} else {
    $error = 'Нет сущ заявок';
}
