<?php
session_start();
require_once 'config.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$errors = [];
$success = false;

// Получаем информацию о курсе, если передан course_id
$courseId = $_GET['course_id'] ?? null;
$course = null;

if ($courseId) {
    $stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND is_active = 1");
    $stmt->execute([$courseId]);
    $course = $stmt->fetch();
}

if (!$course) {
    header('Location: index.php');
    exit;
}

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $desiredDate = trim($_POST['desired_date'] ?? '');
    $paymentMethod = trim($_POST['payment_method'] ?? '');

    // Валидация даты
    if (empty($desiredDate)) {
        $errors['desired_date'] = 'Дата начала обучения обязательна';
    } else {
        $dateParts = explode('.', $desiredDate);
        if (count($dateParts) !== 3 || !checkdate($dateParts[1], $dateParts[0], $dateParts[2])) {
            $errors['desired_date'] = 'Некорректный формат даты (ДД.ММ.ГГГГ)';
        } else {
            $desiredDate = sprintf('%04d-%02d-%02d', $dateParts[2], $dateParts[1], $dateParts[0]);
            $minDate = date('Y-m-d', strtotime('+1 week'));
            if ($desiredDate < $minDate) {
                $errors['desired_date'] = 'Дата начала обучения должна быть не ранее чем через неделю';
            }
        }
    }

    // Валидация способа оплаты
    if (!in_array($paymentMethod, ['cash', 'bank_transfer'])) {
        $errors['payment_method'] = 'Выберите способ оплаты';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO applications (user_id, course_id, desired_start_date, payment_method) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$_SESSION['user_id'], $course['id'], $desiredDate, $paymentMethod])) {
            $success = true;
        } else {
            $errors['general'] = 'Произошла ошибка при отправке заявки. Пожалуйста, попробуйте позже.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подача заявки - Корочки.есть</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h4 mb-0">Корочки.есть</h1>
                <nav>
                    <a href="applications.php" class="text-white mx-2">Мои заявки</a>
                    <a href="logout.php" class="text-white mx-2">Выйти</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h2 class="h5 mb-0">Подача заявки на курс</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Заявка успешно отправлена! <a href="applications.php" class="alert-link">Посмотреть мои заявки</a>.
                            </div>
                        <?php else: ?>
                            <?php if (isset($errors['general'])): ?>
                                <div class="alert alert-danger"><?= $errors['general'] ?></div>
                            <?php endif; ?>

                            <div class="mb-4">
                                <h3 class="h5">Информация о курсе</h3>
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title"><?= htmlspecialchars($course['name']) ?></h4>
                                        <p class="card-text"><?= htmlspecialchars($course['description']) ?></p>
                                        <ul class="list-unstyled">
                                            <li><strong>Длительность:</strong> <?= $course['duration'] ?> дней</li>
                                            <li><strong>Стоимость:</strong> <?= number_format($course['price'], 2, '.', ' ') ?> ₽</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <form method="post">
                                <div class="mb-3">
                                    <label for="desired_date" class="form-label">Желаемая дата начала обучения</label>
                                    <input type="text" class="form-control <?= isset($errors['desired_date']) ? 'is-invalid' : '' ?>" 
                                           id="desired_date" name="desired_date" 
                                           placeholder="ДД.ММ.ГГГГ" value="<?= htmlspecialchars($_POST['desired_date'] ?? '') ?>" required>
                                    <?php if (isset($errors['desired_date'])): ?>
                                        <div class="invalid-feedback"><?= $errors['desired_date'] ?></div>
                                    <?php endif; ?>
                                    <small class="text-muted">Формат: ДД.ММ.ГГГГ (не ранее чем через неделю)</small>
                                </div>

                                <div class="mb-4">
                                    <label class="form-label">Способ оплаты</label>
                                    <div class="form-check <?= isset($errors['payment_method']) ? 'is-invalid' : '' ?>">
                                        <input class="form-check-input" type="radio" name="payment_method" id="cash" 
                                               value="cash" <?= ($_POST['payment_method'] ?? '') === 'cash' ? 'checked' : '' ?> required>
                                        <label class="form-check-label" for="cash">Наличными</label>
                                    </div>
                                    <div class="form-check <?= isset($errors['payment_method']) ? 'is-invalid' : '' ?>">
                                        <input class="form-check-input" type="radio" name="payment_method" id="bank_transfer" 
                                               value="bank_transfer" <?= ($_POST['payment_method'] ?? '') === 'bank_transfer' ? 'checked' : '' ?> required>
                                        <label class="form-check-label" for="bank_transfer">Перевод на банковский счет</label>
                                    </div>
                                    <?php if (isset($errors['payment_method'])): ?>
                                        <div class="invalid-feedback d-block"><?= $errors['payment_method'] ?></div>
                                    <?php endif; ?>
                                </div>

                                <button type="submit" class="btn btn-primary w-100">Отправить заявку</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Корочки.есть - Все права защищены</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Маска для даты
        document.getElementById('desired_date').addEventListener('input', function (e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,2})(\d{0,2})(\d{0,4})/);
            e.target.value = !x[2] ? x[1] : x[1] + '.' + x[2] + (x[3] ? '.' + x[3] : '');
        });
    </script>
</body>
</html>