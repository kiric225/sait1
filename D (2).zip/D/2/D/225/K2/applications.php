<?php
session_start();
require_once 'config.php';

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Получаем заявки пользователя
$stmt = $pdo->prepare("
    SELECT a.*, c.name as course_name, c.description as course_description 
    FROM applications a
    JOIN courses c ON a.course_id = c.id
    WHERE a.user_id = ?
    ORDER BY a.created_at DESC
");
$stmt->execute([$_SESSION['user_id']]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Обработка отправки отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['feedback'], $_POST['application_id'])) {
    $feedback = trim($_POST['feedback']);
    $applicationId = (int)$_POST['application_id'];
    
    // Проверяем, что заявка принадлежит пользователю и завершена
    $stmt = $pdo->prepare("SELECT id FROM applications WHERE id = ? AND user_id = ? AND status = 'completed'");
    $stmt->execute([$applicationId, $_SESSION['user_id']]);
    if ($stmt->fetch()) {
        $updateStmt = $pdo->prepare("UPDATE applications SET feedback = ?, feedback_date = NOW() WHERE id = ?");
        $updateStmt->execute([$feedback, $applicationId]);
        // Обновляем данные на странице
        foreach ($applications as &$app) {
            if ($app['id'] == $applicationId) {
                $app['feedback'] = $feedback;
                $app['feedback_date'] = date('Y-m-d H:i:s');
                break;
            }
        }
        unset($app);
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заявки - Корочки.есть</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h4 mb-0">Корочки.есть</h1>
                <nav>
                    <a href="index.php" class="text-white mx-2">Главная</a>
                    <a href="logout.php" class="text-white mx-2">Выйти</a>
                </nav>
            </div>
        </div>
    </header>

    <main class="container my-5">
        <h2 class="text-center mb-4">Мои заявки</h2>
        
        <?php if (empty($applications)): ?>
            <div class="alert alert-info">
                У вас пока нет заявок. <a href="index.php" class="alert-link">Выбрать курс</a>.
            </div>
        <?php else: ?>
            <div class="accordion" id="applicationsAccordion">
                <?php foreach ($applications as $app): ?>
                    <div class="accordion-item">
                        <h3 class="accordion-header" id="heading<?= $app['id'] ?>">
                            <button class="accordion-button <?= $app['status'] !== 'new' ? '' : 'collapsed' ?>" 
                                    type="button" data-bs-toggle="collapse" 
                                    data-bs-target="#collapse<?= $app['id'] ?>" 
                                    aria-expanded="<?= $app['status'] !== 'new' ? 'true' : 'false' ?>" 
                                    aria-controls="collapse<?= $app['id'] ?>">
                                <span class="me-3"><?= htmlspecialchars($app['course_name']) ?></span>
                                <span class="badge bg-<?= 
                                    $app['status'] === 'new' ? 'warning' : 
                                    ($app['status'] === 'in_progress' ? 'info' : 'success') 
                                ?> text-dark ms-auto">
                                    <?= 
                                        $app['status'] === 'new' ? 'Новая' : 
                                        ($app['status'] === 'in_progress' ? 'Идет обучение' : 'Обучение завершено') 
                                    ?>
                                </span>
                            </button>
                        </h3>
                        <div id="collapse<?= $app['id'] ?>" 
                             class="accordion-collapse collapse <?= $app['status'] !== 'new' ? 'show' : '' ?>" 
                             aria-labelledby="heading<?= $app['id'] ?>" 
                             data-bs-parent="#applicationsAccordion">
                            <div class="accordion-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <h4 class="h6">Информация о курсе</h4>
                                        <p><?= htmlspecialchars($app['course_description']) ?></p>
                                    </div>
                                    <div class="col-md-6">
                                        <h4 class="h6">Информация о заявке</h4>
                                        <ul class="list-unstyled">
                                            <li><strong>Дата подачи:</strong> <?= date('d.m.Y H:i', strtotime($app['created_at'])) ?></li>
                                            <li><strong>Желаемая дата начала:</strong> <?= date('d.m.Y', strtotime($app['desired_start_date'])) ?></li>
                                            <li><strong>Способ оплаты:</strong> <?= $app['payment_method'] === 'cash' ? 'Наличными' : 'Перевод на банковский счет' ?></li>
                                            <li><strong>Статус:</strong> 
                                                <span class="badge bg-<?= 
                                                    $app['status'] === 'new' ? 'warning' : 
                                                    ($app['status'] === 'in_progress' ? 'info' : 'success') 
                                                ?> text-dark">
                                                    <?= 
                                                        $app['status'] === 'new' ? 'Новая' : 
                                                        ($app['status'] === 'in_progress' ? 'Идет обучение' : 'Обучение завершено') 
                                                    ?>
                                                </span>
                                            </li>
                                            <?php if ($app['updated_at']): ?>
                                                <li><strong>Последнее обновление:</strong> <?= date('d.m.Y H:i', strtotime($app['updated_at'])) ?></li>
                                            <?php endif; ?>
                                        </ul>
                                    </div>
                                </div>

                                <?php if ($app['status'] === 'completed'): ?>
                                    <div class="mt-4">
                                        <h5 class="h6">Отзыв о курсе</h5>
                                        <?php if ($app['feedback']): ?>
                                            <div class="card">
                                                <div class="card-body">
                                                    <blockquote class="blockquote mb-0">
                                                        <p><?= htmlspecialchars($app['feedback']) ?></p>
                                                        <footer class="blockquote-footer">Оставлен <?= date('d.m.Y', strtotime($app['feedback_date'])) ?></footer>
                                                    </blockquote>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <form method="post">
                                                <input type="hidden" name="application_id" value="<?= $app['id'] ?>">
                                                <div class="mb-3">
                                                    <label for="feedback<?= $app['id'] ?>" class="form-label">Оставьте ваш отзыв</label>
                                                    <textarea class="form-control" id="feedback<?= $app['id'] ?>" name="feedback" rows="3" required></textarea>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Отправить отзыв</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Корочки.есть - Все права защищены</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>