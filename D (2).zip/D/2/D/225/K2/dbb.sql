-- Модифицированная структура базы данных для системы "Корочки.есть"

-- Таблица пользователей
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `FIO` varchar(60) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `mail` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL, -- Хэш пароля, а не сам пароль
  `isAdmin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `login` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Таблица курсов
CREATE TABLE `courses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  `duration` int DEFAULT NULL, -- Продолжительность в днях
  `price` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Таблица заявок
CREATE TABLE `applications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `course_id` int NOT NULL,
  `desired_start_date` date NOT NULL,
  `payment_method` enum('cash','bank_transfer') NOT NULL,
  `status` enum('new','in_progress','completed') NOT NULL DEFAULT 'new',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `feedback` text,
  `feedback_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `course_id` (`course_id`),
  CONSTRAINT `applications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `applications_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- Добавляем тестовые курсы
INSERT INTO `courses` (`name`, `description`, `duration`, `price`) VALUES
('Основы алгоритмизации и программирования', 'Базовый курс по программированию', 30, 15000.00),
('Основы веб-дизайна', 'Курс по основам дизайна для веба', 20, 12000.00),
('Основы проектирования баз данных', 'Курс по проектированию и работе с базами данных', 25, 13500.00);

-- Добавляем администратора
INSERT INTO `users` (`login`, `FIO`, `phone`, `mail`, `password`, `isAdmin`) VALUES
('admin', 'Администратор Системы', '+7(999)-123-45-67', 'admin@koro4ki.est', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 1);