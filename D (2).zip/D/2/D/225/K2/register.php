<?php
session_start();
require_once 'config.php';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Валидация данных
    $login = trim($_POST['login'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $fio = trim($_POST['fio'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $mail = trim($_POST['mail'] ?? '');

    // Проверка логина
    if (empty($login)) {
        $errors['login'] = 'Логин обязателен для заполнения';
    } elseif (strlen($login) < 6) {
        $errors['login'] = 'Логин должен содержать не менее 6 символов';
    } elseif (!preg_match('/^[а-яА-ЯёЁ0-9]+$/u', $login)) {
        $errors['login'] = 'Логин должен содержать только кириллицу и цифры';
    } else {
        // Проверка уникальности логина
        $stmt = $pdo->prepare("SELECT id FROM users WHERE login = ?");
        $stmt->execute([$login]);
        if ($stmt->fetch()) {
            $errors['login'] = 'Этот логин уже занят';
        }
    }

    // Проверка пароля
    if (empty($password)) {
        $errors['password'] = 'Пароль обязателен для заполнения';
    } elseif (strlen($password) < 6) {
        $errors['password'] = 'Пароль должен содержать не менее 6 символов';
    }

    // Проверка ФИО
    if (empty($fio)) {
        $errors['fio'] = 'ФИО обязательно для заполнения';
    } elseif (!preg_match('/^[а-яА-ЯёЁ\s]+$/u', $fio)) {
        $errors['fio'] = 'ФИО должно содержать только кириллицу и пробелы';
    }

    // Проверка телефона
    if (empty($phone)) {
        $errors['phone'] = 'Телефон обязателен для заполнения';
    } elseif (!preg_match('/^\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $errors['phone'] = 'Телефон должен быть в формате +7(XXX)-XXX-XX-XX';
    }

    // Проверка email
    if (empty($mail)) {
        $errors['mail'] = 'Email обязателен для заполнения';
    } elseif (!filter_var($mail, FILTER_VALIDATE_EMAIL)) {
        $errors['mail'] = 'Некорректный формат email';
    }

    // Если ошибок нет - регистрируем пользователя
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (login, FIO, phone, mail, password) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$login, $fio, $phone, $mail, $hashedPassword])) {
            $success = true;
        } else {
            $errors['general'] = 'Произошла ошибка при регистрации. Пожалуйста, попробуйте позже.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - Корочки.есть</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header class="bg-primary text-white py-3">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <h1 class="h4 mb-0">Корочки.есть</h1>
                <a href="login.php" class="text-white">Вход</a>
            </div>
        </div>
    </header>

    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h2 class="h5 mb-0">Регистрация</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($success): ?>
                            <div class="alert alert-success">
                                Регистрация прошла успешно! <a href="login.php" class="alert-link">Войдите в систему</a>.
                            </div>
                        <?php else: ?>
                            <?php if (isset($errors['general'])): ?>
                                <div class="alert alert-danger"><?= $errors['general'] ?></div>
                            <?php endif; ?>

                            <form method="post">
                                <div class="mb-3">
                                    <label for="login" class="form-label">Логин</label>
                                    <input type="text" class="form-control <?= isset($errors['login']) ? 'is-invalid' : '' ?>" 
                                           id="login" name="login" value="<?= htmlspecialchars($_POST['login'] ?? '') ?>" required>
                                    <?php if (isset($errors['login'])): ?>
                                        <div class="invalid-feedback"><?= $errors['login'] ?></div>
                                    <?php endif; ?>
                                    <small class="text-muted">Не менее 6 символов кириллицы</small>
                                </div>

                                <div class="mb-3">
                                    <label for="password" class="form-label">Пароль</label>
                                    <input type="password" class="form-control <?= isset($errors['password']) ? 'is-invalid' : '' ?>" 
                                           id="password" name="password" required>
                                    <?php if (isset($errors['password'])): ?>
                                        <div class="invalid-feedback"><?= $errors['password'] ?></div>
                                    <?php endif; ?>
                                    <small class="text-muted">Не менее 6 символов</small>
                                </div>

                                <div class="mb-3">
                                    <label for="fio" class="form-label">ФИО</label>
                                    <input type="text" class="form-control <?= isset($errors['fio']) ? 'is-invalid' : '' ?>" 
                                           id="fio" name="fio" value="<?= htmlspecialchars($_POST['fio'] ?? '') ?>" required>
                                    <?php if (isset($errors['fio'])): ?>
                                        <div class="invalid-feedback"><?= $errors['fio'] ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label for="phone" class="form-label">Телефон</label>
                                    <input type="tel" class="form-control <?= isset($errors['phone']) ? 'is-invalid' : '' ?>" 
                                           id="phone" name="phone" placeholder="+7(XXX)-XXX-XX-XX" 
                                           value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>" required>
                                    <?php if (isset($errors['phone'])): ?>
                                        <div class="invalid-feedback"><?= $errors['phone'] ?></div>
                                    <?php endif; ?>
                                </div>

                                <div class="mb-3">
                                    <label for="mail" class="form-label">Email</label>
                                    <input type="email" class="form-control <?= isset($errors['mail']) ? 'is-invalid' : '' ?>" 
                                           id="mail" name="mail" value="<?= htmlspecialchars($_POST['mail'] ?? '') ?>" required>
                                    <?php if (isset($errors['mail'])): ?>
                                        <div class="invalid-feedback"><?= $errors['mail'] ?></div>
                                    <?php endif; ?>
                                </div>

                                <button type="submit" class="btn btn-primary w-100">Зарегистрироваться</button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer text-center">
                        Уже зарегистрированы? <a href="login.php">Войдите в систему</a>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <footer class="bg-dark text-white py-4">
        <div class="container text-center">
            <p class="mb-0">&copy; 2025 Корочки.есть - Все права защищены</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Маска для телефона
        document.getElementById('phone').addEventListener('input', function (e) {
            let x = e.target.value.replace(/\D/g, '').match(/(\d{0,1})(\d{0,3})(\d{0,3})(\d{0,2})(\d{0,2})/);
            e.target.value = !x[2] ? x[1] : x[1] + '(' + x[2] + ')' + (x[3] ? '-' + x[3] : '') + (x[4] ? '-' + x[4] : '') + (x[5] ? '-' + x[5] : '');
        });
    </script>
</body>
</html>