document.addEventListener('DOMContentLoaded', () => {
    // Анимация элементов при загрузке
    const animateElements = () => {
        const elements = document.querySelectorAll('.fade-in');
        elements.forEach((el, index) => {
            el.style.animationDelay = `${index * 0.1}s`;
        });
    };
    
    animateElements();
    
    // Мобильное меню (для адаптива)
    const setupMobileMenu = () => {
        const menuToggle = document.createElement('button');
        menuToggle.className = 'menu-toggle';
        menuToggle.innerHTML = '☰ Меню';
        document.querySelector('header .container').prepend(menuToggle);
        
        menuToggle.addEventListener('click', () => {
            document.querySelector('nav').classList.toggle('active');
        });
    };
    
    if (window.innerWidth < 768) setupMobileMenu();
});