<?php
// Проверка прав администратора
// Получение всех заявок из БД
?>
<h2>Управление заявками</h2>
<table>
    <tr>
        <th>Пользователь</th>
        <th>Курс</th>
        <th>Дата начала</th>
        <th>Способ оплаты</th>
        <th>Статус</th>
        <th>Действия</th>
    </tr>
    <?php foreach ($all_applications as $app): ?>
    <tr>
        <td><?= $app['user_name'] ?></td>
        <td><?= $app['course_name'] ?></td>
        <td><?= $app['start_date'] ?></td>
        <td><?= $app['payment_method'] ?></td>
        <td>
            <select onchange="updateStatus(<?= $app['id'] ?>, this.value)">
                <option value="Новая" <?= $app['status'] === 'Новая' ? 'selected' : '' ?>>Новая</option>
                <option value="Идет обучение" <?= $app['status'] === 'Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                <option value="Обучение завершено" <?= $app['status'] === 'Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
            </select>
        </td>
        <td>
            <button onclick="contactUser(<?= $app['user_id'] ?>)">Связаться</button>
        </td>
    </tr>
    <?php endforeach; ?>
</table>