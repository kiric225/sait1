<?php
// Обработка регистрации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Валидация данных
    // Добавление пользователя в БД
}

// Форма регистрации
?>
<form method="POST">
    <input type="text" name="login" placeholder="Логин (кириллица, min 6 символов)" required>
    <input type="password" name="password" placeholder="Пароль (min 6 символов)" required>
    <input type="text" name="full_name" placeholder="ФИО" required>
    <input type="tel" name="phone" placeholder="Телефон +7(XXX)-XXX-XX-XX" required>
    <input type="email" name="email" placeholder="Email" required>
    <button type="submit">Зарегистрироваться</button>
</form>