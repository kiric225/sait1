<?php
session_start();
// Подключение к базе данных
require_once 'config/db.php';
// Проверка авторизации
$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'];
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Портал онлайн-курсов</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Шапка сайта -->
    <header class="fade-in">
        <div class="container">
            <div class="logo">
                <h1>Корочки.есть</h1>
                <p>Портал дополнительного образования</p>
            </div>
            <nav>
                <ul>
                    <li><a href="index.php">Главная</a></li>
                    <?php if ($isLoggedIn): ?>
                        <li><a href="applications.php">Мои заявки</a></li>
                        <li><a href="new_application.php">Новая заявка</a></li>
                        <li><a href="logout.php">Выйти</a></li>
                    <?php else: ?>
                        <li><a href="login.php">Вход</a></li>
                        <li><a href="register.php">Регистрация</a></li>
                    <?php endif; ?>
                    <?php if ($isAdmin): ?>
                        <li><a href="admin.php">Панель админа</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Основной контент -->
    <main class="fade-in" style="animation-delay: 0.2s;">
        <div class="container">
            <section class="hero">
                <h2>Получите новые знания и сертификаты</h2>
                <p>Онлайн-курсы по современным профессиям с гибким графиком обучения</p>
                <?php if (!$isLoggedIn): ?>
                    <div class="cta-buttons">
                        <a href="register.php" class="btn btn-primary">Начать обучение</a>
                        <a href="login.php" class="btn btn-secondary">Войти в аккаунт</a>
                    </div>
                <?php endif; ?>
            </section>

            <section class="courses">
                <h2>Популярные курсы</h2>
                <div class="course-grid">
                    <div class="course-card">
                        <h3>Основы алгоритмизации</h3>
                        <p>Изучите базовые принципы программирования</p>
                    </div>
                    <div class="course-card">
                        <h3>Веб-дизайн</h3>
                        <p>Создавайте современные интерфейсы</p>
                    </div>
                    <div class="course-card">
                        <h3>Базы данных</h3>
                        <p>Проектируйте и работайте с SQL</p>
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- Подвал -->
    <footer class="fade-in" style="animation-delay: 0.4s;">
        <div class="container">
            <p>© 2023 Корочки.есть. Все права защищены.</p>
        </div>
    </footer>

    <script src="js/main.js"></script>
</body>
</html>