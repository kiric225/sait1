<?php
if (!isset($_SESSION['user']) || isAdmin()) {
    header('Location: ?page=login');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $errors = [];
    $course_id = $_POST['course_id'];
    $start_date = $_POST['start_date'];
    $payment_method = $_POST['payment_method'];

    if (!validateDate($start_date)) {
        $errors[] = 'Некорректная дата (используйте формат ДД.ММ.ГГГГ)';
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO applications (user_id, course_id, start_date, payment_method) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_SESSION['user']['id'], $course_id, date('Y-m-d', strtotime($start_date)), $payment_method]);
        header('Location: ?page=applications');
        exit;
    }
}

$courses = $pdo->query("SELECT * FROM courses")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto; padding: 20px; }
        .error { color: red; margin-bottom: 10px; }
        select, input, button { width: 100%; padding: 8px; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h1>Новая заявка</h1>
    <?php if (!empty($errors)): ?>
        <?php foreach ($errors as $error): ?>
            <div class="error"><?= $error ?></div>
        <?php endforeach; ?>
    <?php endif; ?>
    <form method="post">
        <select name="course_id" required>
            <option value="">Выберите курс</option>
            <?php foreach ($courses as $course): ?>
                <option value="<?= $course['id'] ?>"><?= $course['name'] ?></option>
            <?php endforeach; ?>
        </select>
        <input type="text" name="start_date" placeholder="Дата начала (ДД.ММ.ГГГГ)" required>
        <select name="payment_method" required>
            <option value="">Способ оплаты</option>
            <option value="cash">Наличные</option>
            <option value="bank_transfer">Банковский перевод</option>
        </select>
        <button type="submit">Отправить заявку</button>
    </form>
    <a href="?page=applications">Назад к заявкам</a>
</body>
</html>