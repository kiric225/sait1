-- Создание базы данных
CREATE DATABASE IF NOT EXISTS koro4ki_est CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE koro4ki_est;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    login VARCHAR(20) NOT NULL UNIQUE,
    fio VARCHAR(60) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица курсов
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    duration_hours INT,
    price DECIMAL(10,2)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Таблица заявок
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    course_id INT NOT NULL,
    desired_start_date DATE NOT NULL,
    payment_method ENUM('cash', 'bank_transfer') NOT NULL,
    status ENUM('new', 'in_progress', 'completed') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    feedback TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Добавление тестовых данных
INSERT INTO courses (name, description, duration_hours, price) VALUES
('Основы алгоритмизации и программирования', 'Базовый курс по программированию', 40, 15000.00),
('Основы веб-дизайна', 'Введение в веб-дизайн и UX/UI', 30, 12000.00),
('Основы проектирования баз данных', 'Проектирование и работа с базами данных', 35, 14000.00);

-- Администратор
INSERT INTO users (login, fio, phone, email, password, is_admin) VALUES
('admin', 'Администратор Системы', '+7(999)-123-45-67', 'admin@koro4ki.est', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', TRUE);