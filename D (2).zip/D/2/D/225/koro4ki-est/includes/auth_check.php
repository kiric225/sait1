<?php
session_start();

// Перенаправление неавторизованных пользователей
function requireAuth() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit();
    }
}

// Перенаправление авторизованных пользователей
function requireGuest() {
    if (isset($_SESSION['user_id'])) {
        header('Location: /dashboard.php');
        exit();
    }
}

// Проверка прав администратора
function requireAdmin() {
    requireAuth();
    if (!$_SESSION['is_admin']) {
        header('Location: /dashboard.php');
        exit();
    }
}
?>