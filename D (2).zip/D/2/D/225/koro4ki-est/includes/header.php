<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - <?php echo $title; ?></title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <div class="container">
            <a href="/" class="logo">Корочки.есть</a>
            <nav>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="/dashboard.php">Личный кабинет</a>
                    <a href="/create_application.php">Подать заявку</a>
                    <a href="/logout.php">Выйти</a>
                <?php else: ?>
                    <a href="/login.php">Войти</a>
                    <a href="/register.php">Регистрация</a>
                <?php endif; ?>
            </nav>
        </div>
    </header>
    <main class="container">