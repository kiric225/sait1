<?php
require_once 'includes/auth_check.php';
requireAuth();

$title = 'Подача заявки на обучение';
$additional_scripts = ['validation.js'];
require_once 'includes/header.php';

require_once 'database/db_connection.php';

$errors = [];

// Получаем список курсов
$courses = $pdo->query("SELECT * FROM courses")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $course_id = (int)$_POST['course_id'];
    $desired_start_date = $_POST['desired_start_date'];
    $payment_method = $_POST['payment_method'];
    
    // Валидация
    if (!$course_id) {
        $errors['course_id'] = 'Выберите курс';
    }
    
    if (!preg_match('/^\d{2}\.\d{2}\.\d{4}$/', $desired_start_date)) {
        $errors['desired_start_date'] = 'Дата должна быть в формате ДД.ММ.ГГГГ';
    } else {
        $date_parts = explode('.', $desired_start_date);
        if (!checkdate($date_parts[1], $date_parts[0], $date_parts[2])) {
            $errors['desired_start_date'] = 'Некорректная дата';
        }
    }
    
    if (!in_array($payment_method, ['cash', 'bank_transfer'])) {
        $errors['payment_method'] = 'Выберите способ оплаты';
    }
    
    if (empty($errors)) {
        $date_for_db = implode('-', array_reverse(explode('.', $desired_start_date)));
        
        $stmt = $pdo->prepare("
            INSERT INTO applications 
            (user_id, course_id, desired_start_date, payment_method) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['user_id'],
            $course_id,
            $date_for_db,
            $payment_method
        ]);
        
        $_SESSION['success_message'] = 'Заявка успешно подана!';
        header('Location: /dashboard.php');
        exit();
    }
}
?>

<section class="application-form">
    <h1>Подача заявки на обучение</h1>
    
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <form method="POST" id="application-form">
        <div class="form-group">
            <label for="course_id">Курс</label>
            <select id="course_id" name="course_id" required>
                <option value="">-- Выберите курс --</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['id']; ?>" 
                        <?php if (isset($_POST['course_id']) && $_POST['course_id'] == $course['id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($course['name']); ?> 
                        (<?php echo $course['duration_hours']; ?> часов, <?php echo number_format($course['price'], 2, '.', ' '); ?> руб.)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="form-group">
            <label for="desired_start_date">Желаемая дата начала обучения</label>
            <input type="text" id="desired_start_date" name="desired_start_date" required 
                   pattern="\d{2}\.\d{2}\.\d{4}" placeholder="ДД.ММ.ГГГГ">
        </div>
        
        <div class="form-group">
            <label>Способ оплаты</label>
            <div class="radio-group">
                <label>
                    <input type="radio" name="payment_method" value="cash" 
                        <?php if (isset($_POST['payment_method']) && $_POST['payment_method'] === 'cash') echo 'checked'; ?> required>
                    Наличные
                </label>
                <label>
                    <input type="radio" name="payment_method" value="bank_transfer" 
                        <?php if (isset($_POST['payment_method']) && $_POST['payment_method'] === 'bank_transfer') echo 'checked'; ?>>
                    Банковский перевод
                </label>
            </div>
        </div>
        
        <button type="submit" class="btn">Отправить заявку</button>
    </form>
</section>

<?php require_once 'includes/footer.php'; ?>