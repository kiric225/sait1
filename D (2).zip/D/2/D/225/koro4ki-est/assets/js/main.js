// Обработка формы отзыва
document.addEventListener('DOMContentLoaded', function() {
    // Открытие формы отзыва
    document.querySelectorAll('.open-feedback').forEach(button => {
        button.addEventListener('click', function() {
            const appId = this.getAttribute('data-app-id');
            const form = document.getElementById(`feedback-form-${appId}`);
            form.style.display = 'block';
            this.style.display = 'none';
        });
    });
    
    // Отправка отзыва
    document.querySelectorAll('.submit-feedback').forEach(button => {
        button.addEventListener('click', function() {
            const appId = this.getAttribute('data-app-id');
            const textarea = document.querySelector(`#feedback-form-${appId} .feedback-text`);
            const feedback = textarea.value.trim();
            
            if (feedback.length < 10) {
                alert('Отзыв должен содержать не менее 10 символов');
                return;
            }
            
            fetch('/submit_feedback.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    app_id: appId,
                    feedback: feedback
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    location.reload();
                } else {
                    alert('Ошибка: ' + (data.message || 'Не удалось отправить отзыв'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Произошла ошибка при отправке отзыва');
            });
        });
    });
    
    // Маска для телефона
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            let formattedValue = '';
            
            if (value.length > 0) {
                formattedValue = '+7(' + value.substring(1, 4);
            }
            if (value.length >= 4) {
                formattedValue += ')-' + value.substring(4, 7);
            }
            if (value.length >= 7) {
                formattedValue += '-' + value.substring(7, 9);
            }
            if (value.length >= 9) {
                formattedValue += '-' + value.substring(9, 11);
            }
            
            this.value = formattedValue;
        });
    }
    
    // Маска для даты
    const dateInput = document.getElementById('desired_start_date');
    if (dateInput) {
        dateInput.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            let formattedValue = '';
            
            if (value.length > 0) {
                formattedValue = value.substring(0, 2);
            }
            if (value.length >= 2) {
                formattedValue += '.' + value.substring(2, 4);
            }
            if (value.length >= 4) {
                formattedValue += '.' + value.substring(4, 8);
            }
            
            this.value = formattedValue;
        });
    }
});