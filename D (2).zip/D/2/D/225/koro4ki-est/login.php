<?php
require_once 'includes/auth_check.php';
requireGuest();

$title = 'Авторизация';
require_once 'includes/header.php';

require_once 'database/db_connection.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $password = $_POST['password'];
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->execute([$login]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['login'] = $user['login'];
        $_SESSION['is_admin'] = $user['is_admin'];
        
        if ($user['is_admin']) {
            header('Location: /admin/index.php');
        } else {
            header('Location: /dashboard.php');
        }
        exit();
    } else {
        $error = 'Неверный логин или пароль';
    }
}
?>

<section class="auth-form">
    <h1>Вход в систему</h1>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <?php echo htmlspecialchars($_SESSION['success_message']); ?>
            <?php unset($_SESSION['success_message']); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <div class="form-group">
            <label for="login">Логин</label>
            <input type="text" id="login" name="login" required>
        </div>
        
        <div class="form-group">
            <label for="password">Пароль</label>
            <input type="password" id="password" name="password" required>
        </div>
        
        <button type="submit" class="btn">Войти</button>
    </form>
    
    <p>Нет аккаунта? <a href="/register.php">Зарегистрируйтесь</a></p>
</section>

<?php require_once 'includes/footer.php'; ?>