<?php
require_once '../includes/auth_check.php';
requireAdmin();

$title = 'Панель администратора';
$additional_scripts = ['admin.js'];
require_once '../includes/header.php';

require_once '../database/db_connection.php';

// Получаем статистику
$stats = [
    'total_applications' => $pdo->query("SELECT COUNT(*) FROM applications")->fetchColumn(),
    'new_applications' => $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'new'")->fetchColumn(),
    'in_progress' => $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'in_progress'")->fetchColumn(),
    'completed' => $pdo->query("SELECT COUNT(*) FROM applications WHERE status = 'completed'")->fetchColumn(),
    'total_users' => $pdo->query("SELECT COUNT(*) FROM users WHERE is_admin = FALSE")->fetchColumn()
];
?>

<section class="admin-dashboard">
    <h1>Панель администратора</h1>
    
    <div class="admin-stats">
        <div class="stat-card">
            <h3>Всего заявок</h3>
            <p><?php echo $stats['total_applications']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Новые заявки</h3>
            <p><?php echo $stats['new_applications']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Идет обучение</h3>
            <p><?php echo $stats['in_progress']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Завершено</h3>
            <p><?php echo $stats['completed']; ?></p>
        </div>
        
        <div class="stat-card">
            <h3>Пользователей</h3>
            <p><?php echo $stats['total_users']; ?></p>
        </div>
    </div>
    
    <div class="admin-actions">
        <a href="applications.php" class="btn">Управление заявками</a>
    </div>
</section>

<?php require_once '../includes/footer.php'; ?>