<?php
require_once '../includes/auth_check.php';
requireAdmin();

$title = 'Управление заявками';
$additional_scripts = ['admin.js'];
require_once '../includes/header.php';

require_once '../database/db_connection.php';

// Фильтрация и сортировка
$status_filter = $_GET['status'] ?? 'all';
$sort_by = $_GET['sort'] ?? 'newest';

// Подготовка SQL
$sql = "
    SELECT a.*, u.login, u.fio, u.phone, u.email, c.name as course_name 
    FROM applications a
    JOIN users u ON a.user_id = u.id
    JOIN courses c ON a.course_id = c.id
";

if ($status_filter !== 'all') {
    $sql .= " WHERE a.status = ?";
}

switch ($sort_by) {
    case 'oldest':
        $sql .= " ORDER BY a.created_at ASC";
        break;
    case 'course':
        $sql .= " ORDER BY c.name";
        break;
    default:
        $sql .= " ORDER BY a.created_at DESC";
}

$stmt = $pdo->prepare($sql);
$params = $status_filter !== 'all' ? [$status_filter] : [];
$stmt->execute($params);
$applications = $stmt->fetchAll();
?>

<section class="admin-applications">
    <h1>Управление заявками</h1>
    
    <div class="filters">
        <form method="GET" class="filter-form">
            <div class="form-group">
                <label for="status">Статус:</label>
                <select id="status" name="status" onchange="this.form.submit()">
                    <option value="all" <?php if ($status_filter === 'all') echo 'selected'; ?>>Все</option>
                    <option value="new" <?php if ($status_filter === 'new') echo 'selected'; ?>>Новые</option>
                    <option value="in_progress" <?php if ($status_filter === 'in_progress') echo 'selected'; ?>>Идет обучение</option>
                    <option value="completed" <?php if ($status_filter === 'completed') echo 'selected'; ?>>Завершено</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="sort">Сортировка:</label>
                <select id="sort" name="sort" onchange="this.form.submit()">
                    <option value="newest" <?php if ($sort_by === 'newest') echo 'selected'; ?>>Сначала новые</option>
                    <option value="oldest" <?php if ($sort_by === 'oldest') echo 'selected'; ?>>Сначала старые</option>
                    <option value="course" <?php if ($sort_by === 'course') echo 'selected'; ?>>По курсу</option>
                </select>
            </div>
        </form>
    </div>
    
    <div class="applications-list">
        <?php if (empty($applications)): ?>
            <p>Нет заявок по выбранным критериям</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Курс</th>
                        <th>Пользователь</th>
                        <th>Дата начала</th>
                        <th>Способ оплаты</th>
                        <th>Статус</th>
                        <th>Дата создания</th>
                        <th>Действия</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($applications as $app): ?>
                        <tr>
                            <td><?php echo $app['id']; ?></td>
                            <td><?php echo htmlspecialchars($app['course_name']); ?></td>
                            <td>
                                <?php echo htmlspecialchars($app['fio']); ?><br>
                                <?php echo htmlspecialchars($app['login']); ?><br>
                                <?php echo htmlspecialchars($app['phone']); ?><br>
                                <?php echo htmlspecialchars($app['email']); ?>
                            </td>
                            <td><?php echo date('d.m.Y', strtotime($app['desired_start_date'])); ?></td>
                            <td><?php echo $app['payment_method'] === 'cash' ? 'Наличные' : 'Перевод'; ?></td>
                            <td>
                                <select class="status-select" data-app-id="<?php echo $app['id']; ?>">
                                    <option value="new" <?php if ($app['status'] === 'new') echo 'selected'; ?>>Новая</option>
                                    <option value="in_progress" <?php if ($app['status'] === 'in_progress') echo 'selected'; ?>>Идет обучение</option>
                                    <option value="completed" <?php if ($app['status'] === 'completed') echo 'selected'; ?>>Завершено</option>
                                </select>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($app['created_at'])); ?></td>
                            <td>
                                <?php if (!empty($app['feedback'])): ?>
                                    <button class="btn btn-small view-feedback" data-feedback="<?php echo htmlspecialchars($app['feedback']); ?>">
                                        Посмотреть отзыв
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</section>

<div id="feedback-modal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h3>Отзыв о курсе</h3>
        <div id="feedback-content"></div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>