<?php require 'db.php'; 
if (!isset($_SESSION['user']) || $_SESSION['user']['isAdmin'] != 'Администратор') {
    header('Location: index.php');
    exit;
}

// Обновление статуса
if (isset($_POST['status'])) {
    $stmt = $pdo->prepare("UPDATE tasks SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['id']]);
    header('Location: admin.php');
    exit;
}

// Получение всех заявок
$stmt = $pdo->query("SELECT t.*, u.FIO, u.phone, u.mail FROM tasks t JOIN users u ON t.login = u.login ORDER BY t.id DESC");
$requests = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <title>Панель администратора</title>
</head>
<body>
    <div class="container">
        <h1>Панель администратора</h1>
        <div class="requests">
            <?php foreach($requests as $req): ?>
            <div class="request">
                <h3><?=htmlspecialchars($req['opisanie'])?></h3>
                <p>От: <?=htmlspecialchars($req['FIO'])?> (<?=$req['login']?>)</p>
                <p>Контакты: <?=$req['phone']?>, <?=$req['mail']?></p>
                <p>Статус: <?=$req['status']?></p>
                <?php if($req['status'] != 'Обучение завершено'): ?>
                    <form method="POST">
                        <input type="hidden" name="id" value="<?=$req['id']?>">
                        <select name="status">
                            <option value="Новый" <?=$req['status']=='Новый'?'selected':''?>>Новый</option>
                            <option value="Идет обучение" <?=$req['status']=='Идет обучение'?'selected':''?>>Идет обучение</option>
                            <option value="Обучение завершено" <?=$req['status']=='Обучение завершено'?'selected':''?>>Обучение завершено</option>
                        </select>
                        <button type="submit">Обновить</button>
                    </form>
                <?php endif; ?>
                <?php if(!empty($req['feedback'])): ?>
                    <p><strong>Отзыв:</strong> <?=htmlspecialchars($req['feedback'])?></p>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
        <a href="index.php?logout" class="logout">Выйти</a>
    </div>
</body>
</html>