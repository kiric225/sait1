import sqlite3
from hashlib import sha256

def register_user(username, password, full_name, phone, email):
    """Регистрация нового пользователя"""
    try:
        hashed_password = sha256(password.encode()).hexdigest()
        conn = sqlite3.connect('violations.db')
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO users (username, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)",
            (username, hashed_password, full_name, phone, email)
        )
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False  # Пользователь уже существует
    finally:
        conn.close()

def create_complaint(user_id, car_number, description):
    """Создание нового заявления о нарушении"""
    conn = sqlite3.connect('violations.db')
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO complaints (user_id, car_number, description) VALUES (?, ?, ?)",
        (user_id, car_number, description)
    )
    conn.commit()
    conn.close()

def get_user_complaints(user_id):
    """Получение списка заявлений пользователя"""
    conn = sqlite3.connect('violations.db')
    cursor = conn.cursor()
    cursor.execute(
        "SELECT id, car_number, description, status, created_at FROM complaints WHERE user_id = ? ORDER BY created_at DESC",
        (user_id,)
    )
    complaints = cursor.fetchall()
    conn.close()
    return complaints

def update_complaint_status(complaint_id, new_status):
    """Обновление статуса заявления (для администратора)"""
    conn = sqlite3.connect('violations.db')
    cursor = conn.cursor()
    cursor.execute(
        "UPDATE complaints SET status = ? WHERE id = ?",
        (new_status, complaint_id)
    )
    conn.commit()
    conn.close()