<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verifyCsrfToken();
    // ... остальной код
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    
    $status = ($action === 'confirm') ? 'confirmed' : 'rejected';
    
    if (updateApplicationStatus($application_id, $status)) {
        $_SESSION['message'] = "Статус заявления успешно обновлен";
        $_SESSION['message_type'] = 'success';
    } else {
        $_SESSION['message'] = "Ошибка при обновлении статуса";
        $_SESSION['message_type'] = 'error';
    }
}

redirect('/admin/');
?>