-- Создание базы данных
CREATE DATABASE IF NOT EXISTS narusheniyam_net;
USE narusheniyam_net;

-- Таблица пользователей
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Таблица заявлений
CREATE TABLE applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    car_number VARCHAR(20) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('new', 'confirmed', 'rejected') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Администратор по умолчанию
INSERT INTO users (username, password, full_name, phone, email) 
VALUES ('copp', '$2y$10$N7A7a5bJ9z8Z1q2w3e4r5u6i7o8p9a0s1d2f3g4h5j6k7l8m9n0o1p2', 'Администратор', '+79999999999', 'admin@example.com');