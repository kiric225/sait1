document.addEventListener('DOMContentLoaded', function() {
    // Валидация формы регистрации
    const registerForm = document.querySelector('.auth-form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password');
            if (password.value.length < 6) {
                alert('Пароль должен содержать не менее 6 символов');
                e.preventDefault();
            }
        });
    }
    
    // Валидация номера автомобиля
    const carNumberInput = document.getElementById('car_number');
    if (carNumberInput) {
        carNumberInput.addEventListener('input', function() {
            this.value = this.value.toUpperCase();
        });
    }
    
    // Подтверждение действий
    const rejectButtons = document.querySelectorAll('.btn-danger');
    rejectButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Вы уверены, что хотите отклонить это заявление?')) {
                e.preventDefault();
            }
        });
    });
});