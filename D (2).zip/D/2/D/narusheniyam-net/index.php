<?php 
require_once 'includes/config.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';
?>

<h2>Добро пожаловать на портал "Нарушениям.Нет"</h2>
<p>Наш портал помогает сознательным гражданам сообщать о нарушениях правил дорожного движения для создания более безопасной дорожной среды.</p>

<?php if (!isLoggedIn()): ?>
    <div class="cta-buttons">
        <a href="register.php" class="btn">Зарегистрироваться</a>
        <a href="login.php" class="btn btn-secondary">Войти в систему</a>
    </div>
<?php endif; ?>

<?php
require_once 'includes/footer.php';
?>