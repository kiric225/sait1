<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

requireAuth(); // Требуем авторизации

if (!isLoggedIn()) {
    redirect('login.php');
}

$applications = getUserApplications($_SESSION['user_id']);

require_once 'includes/header.php';
?>

<h2>Мои заявления</h2>

<?php if (empty($applications)): ?>
    <p>У вас пока нет заявлений. <a href="create_application.php">Создать новое заявление</a></p>
<?php else: ?>
    <table class="applications-table">
        <thead>
            <tr>
                <th>№</th>
                <th>Номер автомобиля</th>
                <th>Описание</th>
                <th>Дата создания</th>
                <th>Статус</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($applications as $index => $app): ?>
                <tr>
                    <td><?php echo $index + 1; ?></td>
                    <td><?php echo htmlspecialchars($app['car_number']); ?></td>
                    <td><?php echo htmlspecialchars($app['description']); ?></td>
                    <td><?php echo date('d.m.Y H:i', strtotime($app['created_at'])); ?></td>
                    <td class="status-<?php echo $app['status']; ?>">
                        <?php 
                            switch($app['status']) {
                                case 'new': echo 'Новое'; break;
                                case 'confirmed': echo 'Подтверждено'; break;
                                case 'rejected': echo 'Отклонено'; break;
                            }
                        ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    
    <div class="actions">
        <a href="create_application.php" class="btn">Создать новое заявление</a>
    </div>
<?php endif; ?>

<?php
require_once 'includes/footer.php';
?>