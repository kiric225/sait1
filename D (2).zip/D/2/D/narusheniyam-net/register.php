<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

if (isLoggedIn()) {
    redirect('applications.php');
}
$errors = [];
$username = $full_name = $phone = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    
    // Валидация
    if (empty($username)) $errors[] = "Логин обязателен";
    if (empty($password)) $errors[] = "Пароль обязателен";
    if (empty($full_name)) $errors[] = "ФИО обязательно";
    if (empty($phone)) $errors[] = "Телефон обязателен";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Некорректный email";
    
    if (empty($errors)) {
        try {
            if (registerUser($username, $password, $full_name, $phone, $email)) {
                $_SESSION['message'] = "Регистрация успешна. Теперь вы можете войти.";
                $_SESSION['message_type'] = 'success';
                redirect('login.php');
            }
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                $errors[] = "Пользователь с таким логином уже существует";
            } else {
                $errors[] = "Ошибка регистрации: " . $e->getMessage();
            }
        }
    }
}

require_once 'includes/header.php';
?>

<h2>Регистрация</h2>

<?php if (!empty($errors)): ?>
    <div class="alert error">
        <ul>
            <?php foreach ($errors as $error): ?>
                <li><?php echo $error; ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<form method="POST" class="auth-form">
    <div class="form-group">
        <label for="username">Логин:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
    </div>
    
    <div class="form-group">
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
    </div>
    
    <div class="form-group">
        <label for="full_name">ФИО:</label>
        <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" required>
    </div>
    
    <div class="form-group">
        <label for="phone">Телефон:</label>
        <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" required>
    </div>
    
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
    </div>
    
    <button type="submit" class="btn">Зарегистрироваться</button>
</form>

<p>Уже есть аккаунт? <a href="login.php">Войдите</a></p>

<?php
require_once 'includes/footer.php';
?>