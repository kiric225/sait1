<?php
session_start();
require_once('connection.php');
// Retrieve form data
$login = $_POST['login'];
$password = $_POST['password'];

// Check if user exists
$sql = "SELECT * FROM users WHERE login='$login' AND password='$password'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Set login and isAdmin cookies
    setcookie("login", $login, time() + (86400 * 30), "/");
    $row = $result->fetch_assoc();
    setcookie("isAdmin", $row['isAdmin'], time() + (86400 * 30), "/");
    // Set user_id in session
    $_SESSION['user_id'] = $row['id'];
    header("Location: index.php"); // Redirect to main page
} else {
    echo "Неверный логин или пароль";
}

$conn->close();
