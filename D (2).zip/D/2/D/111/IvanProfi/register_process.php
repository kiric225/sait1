<?php
require_once('connection.php');

// Retrieve form data
$login = $_POST['login'];
$password = $_POST['password'];
$phone = $_POST['phone'];
$mail = $_POST['mail'];

// Check if user already exists
$sql = "SELECT * FROM users WHERE login='$login'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Пользователь уже существует";
} else {
    // Insert new user into database
    $sql = "INSERT INTO users (login, password, phone, mail) VALUES ('$login', '$password', '$phone', '$mail')";
    if ($conn->query($sql) === TRUE) {
        echo "Новая запись успешно создана";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();