<!-- login.html -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация</title>
</head>
<style>
    body {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        margin: 0;
    }

    form {
        text-align: center;
        box-shadow: 2px 2px 15px black;
        border-radius: 15px;
        padding: 10px;
    }

    h2 {
        margin-bottom: 20px;
    }

    input[type="text"],
    input[type="password"],
    button {
        margin-bottom: 10px;
        border-radius: 5px;
    }
</style>

<body>

    <form action="login_process.php" method="POST">
        <h2>Авторизация</h2>
        <input type="text" name="login" placeholder="Логин"><br><br>
        <input type="password" name="password" placeholder="Пароль"><br><br>
        <button type="submit">войти</button><br>
        <a href="register.php">Регистрация</a>
    </form>
</body>

</html>