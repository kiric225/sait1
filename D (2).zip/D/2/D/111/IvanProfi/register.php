<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        form {
            text-align: center;
            box-shadow: 2px 2px 15px black;
            padding: 10px;
            border-radius: 15px;
        }

        h2 {
            margin-bottom: 20px;
        }

        input[type="text"],
        input[type="password"],
        button {
            margin-bottom: 10px;
            border-radius: 5px;
        }
    </style>
</head>

<body>
    <form action="register_process.php" method="POST">
        <h2>Регистрация</h2>
        <input type="text" name="login" placeholder="Логин"><br><br>
        <input type="password" name="password" placeholder="Пароль"><br><br>
        <input type="phone" name="phone" placeholder="телефон"><br><br>
        <input type="mail" name="mail" placeholder="Почта"><br><br>
        <button type="submit">Зарегистрироваться</button><br>
        <a href="login.php">Авторизироваться</a>
    </form>
</body>

</html>