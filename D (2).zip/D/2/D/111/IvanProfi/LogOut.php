<?php
// logout.php
session_destroy();
// Reset cookies and redirect to login page
setcookie("login", "", time() - 3600, "/");
setcookie("isAdmin", "", time() - 3600, "/");

header("Location: login.php");
exit();
