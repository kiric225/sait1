<?php
// index.php

// Check if user is logged in
if (!isset($_COOKIE['login'])) {
    header("Location: login.php"); // Redirect to login page
    exit();
}

// Check if isAdmin cookie is set to 1
if ($_COOKIE['isAdmin'] == 1) {
    header("Location: admin.php"); // Redirect to admin page
    exit();
}

// Display main page content here
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Main Page</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="#">Главная</a></li>
                <li><a href="LogOut.php">Авторизация</a></li>
                <li><a href="register.php">Регистрация</a></li>
                <li><a href="create_application.php">Оставить заявку</a></li>
                <li> <a href="my_applications.php">Мои заявки</a></li>
            </ul>
        </nav>
        <div class="auth">
            <span>Добро пожаловать, <?php echo $_COOKIE['login']; ?></span>
            <button onclick="location.href='logout.php';">ВЫЙТИ</button>
        </div>
    </header>
    <main>

        <div class="block block_2">
            <h2></h2>
            <p>
            </p>
            <div class="pagination">
        </div>
    </main>

</body>

</html>