<?php
session_start();
require_once 'connection.php';

$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM applications WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$applications = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Мои заявки</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="#">Главная</a></li>
                <li><a href="LogOut.php">Авторизация</a></li>
                <li><a href="register.php">Регистрация</a></li>
                <li><a href="create_application.php">Оставить заявку</a></li>
                <li> <a href="my_applications.php">Мои заявки</a></li>
            </ul>
        </nav>
        <div class="auth">
            <span>Добро пожаловать, <?php echo $_COOKIE['login']; ?></span>
            <button onclick="location.href='logout.php';">ВЫЙТИ</button>
        </div>
    </header>
    <h1>Мои заявки</h1>
    <div class="contaner">
        <table border="1">
            <tr>
                <th>Дата и время</th>
                <th>Номер автомобиля</th>
                <th>Нарушение</th>
                <th>Статус</th>
            </tr>
            <?php foreach ($applications as $application): ?>
                <tr>
                    <td><?php echo $application['created_at']; ?></td>
                    <td><?php echo $application['title']; ?></td>
                    <td><?php echo $application['description']; ?></td>
                    <td><?php echo $application['status']; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="register.php">Назад</a>
    </div>

</body>

</html>