<?php
// admin.php

// Check if user is logged in
if (!isset($_COOKIE['login'])) {
    header("Location: login.php"); // Redirect to login page
    exit();
}

// Check if isAdmin cookie is set to 1
if ($_COOKIE['isAdmin'] != 1) {
    header("Location: index.php"); // Redirect non-admin users to main page
    exit();
}

// Подключение к базе данных
require_once('connection.php');

// Создание соединения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL запрос для выборки всех пользователей
$sql = "SELECT login FROM users";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update'])) {
        $app_id = $_POST['app_id'];
        $status = $_POST['status'];

        $stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $app_id);
        if ($stmt->execute()) {
            echo "Status updated successfully";
        } else {
            echo "Error updating status: " . $stmt->error;
        }
    } elseif (isset($_POST['delete'])) {
        $app_id = $_POST['app_id'];

        $stmt = $conn->prepare("DELETE FROM applications WHERE id = ?");
        $stmt->bind_param("i", $app_id);
        if ($stmt->execute()) {
            echo "Application deleted successfully";
        } else {
            echo "Error deleting application: " . $stmt->error;
        }
    }

    header("Location: admin.php");
    exit(); // Ensure no further code is executed after the redirect
}

$stmt = $conn->query("SELECT applications.*, users.login FROM applications JOIN users ON applications.user_id = users.id");
$applications = $stmt->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Страница администратора</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="#">Главная</a></li>
                <li><a href="LogOut.php">Авторизация</a></li>
                <li><a href="register.php">Регистрация</a></li>
            </ul>
        </nav>
        <div class="auth">
            <span>Добро пожаловать, <?php echo $_COOKIE['login']; ?></span>
            <button onclick="location.href='Logout.php';">ВЫЙТИ</button>
        </div>
    </header>
    <main>
        <h1>Добро пожаловать в панель администратора.</h1>
        <div class="panel_users">
            <h2>Список пользователей: </h2>
            <?php
            if ($result->num_rows > 0) {
                // Вывод данных каждого пользователя
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>" . 'Пользователь: ' . $row["login"] . "</li>";
                }
                echo "</ul>";
            } else {
                echo "0 results"; // Если нет пользователей в базе данных
            }

            $conn->close(); ?>
        </div>
        <div class="table-container">
            <table border="1">
                <tr>
                    <th>Дата и время</th>
                    <th>Пользователь</th>
                    <th>Номер автомобиля</th>
                    <th>Нарушение</th>
                    <th>Статус</th>
                    <th>Действия</th>
                </tr>
                <?php foreach ($applications as $application): ?>
                    <tr>
                        <td><?php echo $application['created_at']; ?></td>
                        <td><?php echo $application['login']; ?></td>
                        <td><?php echo $application['title']; ?></td>
                        <td><?php echo $application['description']; ?></td>
                        <td>
                            <form action="admin.php" method="POST">
                                <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                <select name="status">
                                    <option value="в ожидании" <?php if ($application['status'] == 'в ожидании') echo 'selected'; ?>>в ожидании</option>
                                    <option value="одобренно" <?php if ($application['status'] == 'одобренно') echo 'selected'; ?>>одобренно</option>
                                    <option value="отклонено" <?php if ($application['status'] == 'отклонено') echo 'selected'; ?>>отклонено</option>
                                </select>
                                <input class="btn_tbl" type="submit" name="update" value="Обновить">
                            </form>
                        </td>
                        <td>
                            <form action="admin.php" method="POST">
                                <input type="hidden" name="app_id" value="<?php echo $application['id']; ?>">
                                <input class="btn_tbl" type="submit" name="delete" value="Удалить" onclick="return confirm('Вы уверены?');">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </main>

</body>

</html>