<?php
session_start();
require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $user_id = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO applications (user_id, title, description) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $title, $description);
    $stmt->execute();

    header("Location: my_applications.php");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Оставить заявку</title>
</head>

<body>
    <header>
        <nav>
            <ul>
                <li><a href="#">Главная</a></li>
                <li><a href="LogOut.php">Авторизация</a></li>
                <li><a href="register.php">Регистрация</a></li>
                <li><a href="create_application.php">Оставить заявку</a></li>
                <li> <a href="my_applications.php">Мои заявки</a></li>
            </ul>
        </nav>
        <div class="auth">
            <span>Добро пожаловать, <?php echo $_COOKIE['login']; ?></span>
            <button onclick="location.href='logout.php';">ВЫЙТИ</button>
        </div>
    </header>
    <h1>Оставить заявку</h1>
    <div class="containerAppCre">
        <form action="create_application.php" method="POST">
            <label for="title">номер автомобиля:</label><br>
            <input type="text" id="title" name="title" required><br><br>
            <label for="description">Описание нарушения:</label><br>
            <textarea id="description" name="description" required></textarea><br><br>
            <input class="create_app_btn" type="submit" value="Отправить">
        </form>
        <a href="register.php">Назад</a>
    </div>
</body>

</html>