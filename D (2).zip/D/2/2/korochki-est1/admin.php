<?php 
include 'db.php';

if (!isAdmin()) {
    header("Location: index.php");
    exit;
}

// Обновление статуса заявки
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['app_id'])) {
    $stmt = $pdo->prepare("UPDATE applications SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['app_id']]);
}

// Получение всех заявок
$stmt = $pdo->query("SELECT a.*, u.FIO FROM applications a JOIN users u ON a.login = u.login");
$applications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Панель администратора</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Панель администратора</h1>
        <a href="dashboard.php" class="btn">Личный кабинет</a>
        <a href="logout.php" class="logout">Выйти</a>
        
        <h2>Все заявки</h2>
        <div class="applications">
            <?php foreach ($applications as $app): ?>
                <div class="application">
                    <h3><?= htmlspecialchars($app['course_name']) ?></h3>
                    <p>Студент: <?= htmlspecialchars($app['FIO']) ?></p>
                    <p>Дата начала: <?= htmlspecialchars($app['start_date']) ?></p>
                    <p>Способ оплаты: <?= htmlspecialchars($app['payment_method']) ?></p>
                    <p>Статус: <?= htmlspecialchars($app['status']) ?></p>
                    
                    <?php if ($app['status'] !== 'Обучение завершено'): ?>
                        <form method="post">
                            <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                            <select name="status">
                                <option value="Новый" <?= $app['status'] === 'Новый' ? 'selected' : '' ?>>Новый</option>
                                <option value="Идет обучение" <?= $app['status'] === 'Идет обучение' ? 'selected' : '' ?>>Идет обучение</option>
                                <option value="Обучение завершено" <?= $app['status'] === 'Обучение завершено' ? 'selected' : '' ?>>Обучение завершено</option>
                            </select>
                            <button type="submit">Обновить статус</button>
                        </form>
                    <?php endif; ?>
                    
                    <?php if (!empty($app['feedback'])): ?>
                        <p><strong>Отзыв:</strong> <?= htmlspecialchars($app['feedback']) ?></p>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>