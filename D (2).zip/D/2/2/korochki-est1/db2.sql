Проблемы в исходном коде:

Удалена повторная команда добавления поля feedback (оно уже добавляется в первом ALTER TABLE)

Упрощена структура запросов

Если у вас все равно возникают проблемы, попробуйте выполнить эти запросы по одному:

sql
-- Шаг 1: Переименование таблицы
ALTER TABLE `tasks` RENAME TO `applications`;

-- Шаг 2: Изменение столбца number_auto
ALTER TABLE `applications` CHANGE `number_auto` `course_name` VARCHAR(100) NOT NULL;

-- Шаг 3: Изменение столбца opisanie
ALTER TABLE `applications` CHANGE `opisanie` `start_date` DATE NOT NULL;

-- Шаг 4: Добавление payment_method
ALTER TABLE `applications` ADD `payment_method` VARCHAR(50) NOT NULL AFTER `start_date`;

-- Шаг 5: Добавление feedback
ALTER TABLE `applications` ADD `feedback` TEXT NULL AFTER `status`;

-- Шаг 6: Обновление администратора
UPDATE `users` SET `login` = 'admin', `password` = 'education' WHERE `id` = 1;