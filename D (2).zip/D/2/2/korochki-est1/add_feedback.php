<?php
include 'db.php';

if (!isset($_SESSION['user']) || isAdmin()) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("UPDATE applications SET feedback = ? WHERE id = ? AND login = ?");
    $stmt->execute([
        $_POST['feedback'],
        $_POST['app_id'],
        $_SESSION['user']['login']
    ]);
    
    header("Location: dashboard.php");
    exit;
}

header("Location: dashboard.php");
exit;
?>