<?php include 'db.php'; ?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Регистрация</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Регистрация</h1>
        <form action="dashboard.php" method="post" id="registerForm">
            <div class="form-group">
                <label for="login">Логин (кириллица, от 6 символов):</label>
                <input type="text" id="login" name="login" pattern="[А-Яа-яЁё]{6,}" required>
            </div>
            <div class="form-group">
                <label for="password">Пароль (от 6 символов):</label>
                <input type="password" id="password" name="password" minlength="6" required>
            </div>
            <div class="form-group">
                <label for="fio">ФИО:</label>
                <input type="text" id="fio" name="fio" pattern="[А-Яа-яЁё\s]+" required>
            </div>
            <div class="form-group">
                <label for="phone">Телефон (+7(XXX)-XXX-XX-XX):</label>
                <input type="tel" id="phone" name="phone" pattern="\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}" required>
            </div>
            <div class="form-group">
                <label for="mail">Email:</label>
                <input type="email" id="mail" name="mail" required>
            </div>
            <button type="submit">Зарегистрироваться</button>
        </form>
        <p>Уже есть аккаунт? <a href="index.php">Войдите</a></p>
    </div>
    <script src="script.js"></script>
</body>
</html>