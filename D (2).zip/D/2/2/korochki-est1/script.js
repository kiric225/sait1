document.addEventListener('DOMContentLoaded', function() {
    // Валидация формы регистрации
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const phone = document.getElementById('phone');
            const phonePattern = /\+7\(\d{3}\)-\d{3}-\d{2}-\d{2}/;
            
            if (!phonePattern.test(phone.value)) {
                alert('Пожалуйста, введите телефон в формате +7(XXX)-XXX-XX-XX');
                e.preventDefault();
            }
        });
    }
    
    // Маска для телефона
    const phoneInput = document.getElementById('phone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function(e) {
            let value = this.value.replace(/\D/g, '');
            
            if (value.length > 0) {
                value = '+7(' + value.substring(1, 4) + ')-' + value.substring(4, 7) + '-' + value.substring(7, 9) + '-' + value.substring(9, 11);
            }
            
            this.value = value;
        });
    }
});