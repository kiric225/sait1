<?php 
include 'db.php';

if (!isset($_SESSION['user']) || isAdmin()) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO applications (login, course_name, start_date, payment_method, status) VALUES (?, ?, ?, ?, 'Новый')");
    $stmt->execute([
        $_SESSION['user']['login'],
        $_POST['course'],
        $_POST['start_date'],
        $_POST['payment']
    ]);
    
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Новая заявка</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Новая заявка на обучение</h1>
        <form method="post">
            <div class="form-group">
                <label for="course">Курс:</label>
                <select id="course" name="course" required>
                    <option value="Основы алгоритмизации и программирования">Основы алгоритмизации и программирования</option>
                    <option value="Основы веб-дизайна">Основы веб-дизайна</option>
                    <option value="Основы проектирования баз данных">Основы проектирования баз данных</option>
                </select>
            </div>
            <div class="form-group">
                <label for="start_date">Желаемая дата начала:</label>
                <input type="date" id="start_date" name="start_date" required>
            </div>
            <div class="form-group">
                <label>Способ оплаты:</label>
                <div class="radio-group">
                    <label><input type="radio" name="payment" value="Наличные" required> Наличные</label>
                    <label><input type="radio" name="payment" value="Банковский перевод"> Банковский перевод</label>
                </div>
            </div>
            <button type="submit">Отправить заявку</button>
        </form>
        <a href="dashboard.php" class="btn">Назад</a>
    </div>
</body>
</html>