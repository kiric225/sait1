<?php 
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['login']) {
        // Авторизация
        $stmt = $pdo->prepare("SELECT * FROM users WHERE login = ?");
        $stmt->execute([$_POST['login']]);
        $user = $stmt->fetch();
        
        if ($user && $user['password'] === $_POST['password']) {
            $_SESSION['user'] = $user;
        } else {
            header("Location: index.php?error=1");
            exit;
        }
    } elseif (isset($_POST['fio'])) {
        // Регистрация
        $stmt = $pdo->prepare("INSERT INTO users (login, FIO, phone, mail, password) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['login'],
            $_POST['fio'],
            $_POST['phone'],
            $_POST['mail'],
            $_POST['password']
        ]);
        
        $userId = $pdo->lastInsertId();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->execute([$userId]);
        $_SESSION['user'] = $stmt->fetch();
    }
}

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

// Получаем заявки пользователя
$stmt = $pdo->prepare("SELECT * FROM applications WHERE login = ?");
$stmt->execute([$_SESSION['user']['login']]);
$applications = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корочки.есть - Личный кабинет</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Добро пожаловать, <?= htmlspecialchars($_SESSION['user']['FIO']) ?>!</h1>
        
        <?php if (isAdmin()): ?>
            <a href="admin.php" class="btn">Панель администратора</a>
        <?php else: ?>
            <a href="create_app.php" class="btn">Создать новую заявку</a>
        <?php endif; ?>
        
        <h2>Ваши заявки</h2>
        <?php if (empty($applications)): ?>
            <p>У вас пока нет заявок</p>
        <?php else: ?>
            <div class="applications">
                <?php foreach ($applications as $app): ?>
                    <div class="application">
                        <h3><?= htmlspecialchars($app['course_name']) ?></h3>
                        <p>Дата начала: <?= htmlspecialchars($app['start_date']) ?></p>
                        <p>Способ оплаты: <?= htmlspecialchars($app['payment_method']) ?></p>
                        <p>Статус: <?= htmlspecialchars($app['status']) ?></p>
                        
                        <?php if ($app['status'] === 'Обучение завершено' && empty($app['feedback'])): ?>
                            <form action="add_feedback.php" method="post">
                                <input type="hidden" name="app_id" value="<?= $app['id'] ?>">
                                <textarea name="feedback" placeholder="Оставьте отзыв" required></textarea>
                                <button type="submit">Отправить отзыв</button>
                            </form>
                        <?php elseif (!empty($app['feedback'])): ?>
                            <p><strong>Ваш отзыв:</strong> <?= htmlspecialchars($app['feedback']) ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <a href="logout.php" class="logout">Выйти</a>
    </div>
</body>
</html>